using System;

namespace Server.Networking.TCP
{
    public delegate void ConnectionEvent(ConnectionHandle c);
    public static class ConnectionHandler
    {
        public static event ConnectionEvent ConnectionLimitReached;
        public static event ConnectionEvent ConnectionAdding;
        public static event ConnectionEvent ConnectionAdded;
        public static event TCPDataEvent DataRecieved;
        public static event TCPDataEvent DataSent;
        public static event TCPDataEvent ConnectionLost;
        public static ConnectionHandle[] Connections = new ConnectionHandle[0];
        /// <summary>
        /// Maximum number of open connections, less than 1 disables checking
        /// </summary>
        public static int MaxConnections = 0;
        public static System.Text.Encoding Encoding = System.Text.Encoding.ASCII;
        public static UInt32 Buffersize = 8192;
        public static char Delimiter = '\n';
        public static bool Add(System.Net.Sockets.TcpClient client)
        {
            ConnectionHandle c = new ConnectionHandle(client, Encoding, Buffersize, Delimiter, Connections.Length);
            if (ConnectionAdding != null) ConnectionAdding(c);
            if (c.Aborted()) return false;
            if (MaxConnections > 0)
            {
                if (Connections.Length >= MaxConnections)
                {
                    if (ConnectionLimitReached != null) ConnectionLimitReached(c);
                    return false;
                }
            }
            c.Socket.DataSent += new TCPDataEvent(InvokeDataSent);
            c.Socket.DataRecieved += new TCPDataEvent(InvokeDataRecieved);
            c.Socket.ConnectionClosed += new TCPDataEvent(InvokeConnectionLost);
            Array.Resize(ref Connections, Connections.Length + 1);
            Connections[Connections.Length - 1] = c;
            if (ConnectionAdded != null) ConnectionAdded(c);
            return true;
        }
        public static void InvokeDataSent(ConnectionEventArgs e)
        {
            if (DataSent != null) DataSent(e);
        }
        public static void InvokeDataRecieved(ConnectionEventArgs e)
        {
            if (DataRecieved != null) DataRecieved(e);
        }
        public static void InvokeConnectionLost(ConnectionEventArgs e)
        {
            if (ConnectionLost != null) ConnectionLost(e);
        }
        public static bool Remove(int id)
        {
            if (id >= Connections.Length) return false;
            Connections[id].Abort();
            ConnectionHandle[] temp = new ConnectionHandle[Connections.Length - 1];
            for (int i = 0; i < id; i++)
                temp[i] = Connections[i];
            for (int i = id + 1; i < Connections.Length; i++)
                temp[i - 1] = Connections[i];
            Connections = temp;
            return true;
        }
        public static void Stop()
        {
            for (int i =0; i < Connections.Length;i++)
            {
                Connections[i].Socket.Stop();
                Connections[i].Abort();
            }
        }
    }
    public class ConnectionHandle
    {
        public Connection Socket;
        public readonly System.Text.Encoding Encoding;
        public readonly System.Net.IPAddress RemoteIP;
        public readonly int RemotePort;
        public readonly System.Net.IPEndPoint RemoteIPEndPoint;
        public readonly System.Net.IPAddress LocalIP;
        public readonly int LocalPort;
        public readonly System.Net.IPEndPoint LocalIPEndPoint;
        public readonly UInt32 Buffersize;
        public readonly char Delimiter;
        public bool Aborted()
        {
            return aborted;
        }
        private bool aborted = false;
        public ConnectionHandle(System.Net.Sockets.TcpClient client, System.Text.Encoding encoding, UInt32 buffersize, char delimiter, int id)
        {
            Socket = new Connection(client, encoding, buffersize, delimiter, id);
            Buffersize = buffersize;
            Delimiter = delimiter;
            Encoding = encoding;
            RemoteIPEndPoint = (System.Net.IPEndPoint)client.Client.RemoteEndPoint;
            RemoteIP = RemoteIPEndPoint.Address;
            RemotePort = RemoteIPEndPoint.Port;
            LocalIPEndPoint = (System.Net.IPEndPoint)client.Client.LocalEndPoint;
            LocalIP = LocalIPEndPoint.Address;
            LocalPort = LocalIPEndPoint.Port;
        }
        public void Abort()
        {
            Socket.Abort();
            this.aborted = true;
        }
    }
}
