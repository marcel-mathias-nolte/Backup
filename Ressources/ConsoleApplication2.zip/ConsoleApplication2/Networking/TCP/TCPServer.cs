using System;

namespace Server.Networking.TCP
{
    public delegate void TCPServerConnEvent(System.Net.Sockets.TcpClient c);
    public delegate void TCPServerEvent(TCPServerEventArgs e);
    public class TCPServer
    {
        private UInt16 port;
        public TCPServerWorker[] Worker;
        private System.Threading.Thread[] WorkerThread;
        public void Start(System.Net.IPAddress[] Adressen, UInt16 Port)
        {
            port = Port;
            Worker = new TCPServerWorker[Adressen.Length];
            WorkerThread = new System.Threading.Thread[Adressen.Length];
            TCPServerEventArgs e;
            for (int i = 0; i < Adressen.Length; i++)
            {
                e = new TCPServerEventArgs(TCPServerEventArgs.EventReason.Starting, i);
                Invoke(e);
                if (!e.Handled)
                {
                    Worker[i] = new TCPServerWorker(new System.Net.Sockets.TcpListener(Adressen[i], Port), this, i);
                    WorkerThread[i] = new System.Threading.Thread(new System.Threading.ThreadStart(Worker[i].Listen));
                    WorkerThread[i].Start();
                    Invoke(new TCPServerEventArgs(TCPServerEventArgs.EventReason.Started, i));
                }
            }
        }
        public event TCPServerEvent ConnectionPending;
        public event TCPServerEvent ServerStopping;
        public event TCPServerEvent ServerStopped;
        public event TCPServerEvent ServerStarting;
        public event TCPServerEvent ServerStarted;
        public void Invoke(TCPServerEventArgs e)
        {
            if (e.Handled) return;
            switch (e.Reason)
            {
                case TCPServerEventArgs.EventReason.Pending:
                    if (ConnectionPending != null) ConnectionPending(e);
                    break;
                case TCPServerEventArgs.EventReason.Stopping:
                    if (ServerStopping != null) ServerStopping(e);
                    break;
                case TCPServerEventArgs.EventReason.Stopped:
                    if (ServerStopped != null) ServerStopped(e);
                    break;
                case TCPServerEventArgs.EventReason.Starting:
                    if (ServerStarting != null) ServerStarting(e);
                    break;
                case TCPServerEventArgs.EventReason.Started:
                    if (ServerStarted != null) ServerStarted(e);
                    break;
                default:
                    throw new Exception("Ein ung�ltiger Eventcode wurde an den Eventhandler �bergeben.");
            }
        }
        public void Stop()
        {
            foreach (Server.Networking.TCP.TCPServerWorker w in Worker)
                w.Stop();
            foreach (System.Threading.Thread t in WorkerThread)
                if (t != null) t.Abort();
        }
        public event TCPServerConnEvent ConnectionAccepted;
        public void Invoke(System.Net.Sockets.TcpClient c)
        {
            if (ConnectionAccepted != null) ConnectionAccepted(c);
        }
    }
    public class TCPServerEventArgs
    {
        public readonly int Reason;
        public bool Handled = false;
        public static class EventReason
        {
            public const int Unknown = 0, Stopping = 1, Stopped = 2, Pending = 3, Starting = 4, Started = 5;
        }
        public readonly int index;
        public TCPServerEventArgs(int Reason, int id)
        {
            this.Reason = Reason;
            index = id;
        }
    }
    public class TCPServerWorker
    {
        public System.Net.Sockets.TcpListener Socket;
        private TCPServer Handle;
        private bool RaiseExit = false;
        private int id;
        public TCPServerWorker(System.Net.Sockets.TcpListener socket, TCPServer handle, int id)
        {
            Socket = socket;
            Handle = handle;
            this.id = id;
        }
        public void Listen()
        {
            TCPServerEventArgs e;
            try
            {
                Socket.Start();
                do
                {
                    while (!RaiseExit)
                    {
                        if (Socket.Pending())
                        {
                            e = new TCPServerEventArgs(TCPServerEventArgs.EventReason.Pending, id);
                            Handle.Invoke(e);
                            if (!e.Handled) Handle.Invoke(Socket.AcceptTcpClient());
                        }
                        System.Threading.Thread.Sleep(5);
                    }
                    e = new TCPServerEventArgs(TCPServerEventArgs.EventReason.Stopping, id);
                    Handle.Invoke(e);
                }
                while (e.Handled);
            }
            catch { }
            Socket.Stop();
            Handle.Invoke(new TCPServerEventArgs(TCPServerEventArgs.EventReason.Stopped, id));
        }
        public void Stop()
        {
            TCPServerEventArgs e = new TCPServerEventArgs(TCPServerEventArgs.EventReason.Stopping, id);
            Handle.Invoke(e);
            if (e.Handled) return;
            RaiseExit = true;
        }
    }
}
