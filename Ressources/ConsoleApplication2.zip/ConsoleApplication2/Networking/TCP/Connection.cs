using System;
using System.Collections.Generic;
using System.Text;

namespace Server.Networking.TCP
{
    /// <summary>
    /// Wird ausgel�st wenn Daten empfangen/gesendet wurden.
    /// </summary>
    /// <param name="e">Die VErbindungsdaten</param>
    public delegate void TCPDataEvent(ConnectionEventArgs e);
    public class Connection
    {
        public event TCPDataEvent DataRecieved;
        public event TCPDataEvent DataSent;
        public event TCPDataEvent ConnectionClosed;
        public System.Net.Sockets.TcpClient socket;
        public System.Net.Sockets.NetworkStream basestream;
        public System.IO.StreamWriter output;
        private System.Threading.Thread Listener;
        private System.Text.Encoding encoding;
        ConnectionWorkingThread WorkingThread;
        public readonly int id;
        public Connection(System.Net.Sockets.TcpClient connection, System.Text.Encoding encoding, UInt32 readbuffersize, char delimiter, int id)
        {
            this.id = id;
            socket = connection;
            basestream = socket.GetStream();
            output = new System.IO.StreamWriter(basestream);
            this.encoding = encoding;
            WorkingThread = new ConnectionWorkingThread(basestream, this, readbuffersize);
            System.Threading.ParameterizedThreadStart Handler = new System.Threading.ParameterizedThreadStart(WorkingThread.WaitTillDelimiter);
            Listener = new System.Threading.Thread(Handler);
            Listener.Start(delimiter);
        }
        public void Invoke(ConnectionEventArgs e)
        {
            // NOT THREAD-SAFE!
            if (e.Recieved) if (DataRecieved != null) DataRecieved(e);
            if (e.Sent) if (DataSent != null) DataSent(e);
            if (e.Dead) if (ConnectionClosed != null) ConnectionClosed(e);
        }
        public void Write(string text)
        {
            output.Write(text);
            output.Flush();
            Invoke(new ConnectionEventArgs(encoding.GetBytes(text),false,this));
        }
        public void Stop()
        {
            WorkingThread.Stop();
        }
        public void Abort()
        {
            if (socket.Connected) socket.Close();
        }
    }
    public class ConnectionEventArgs
    {
        /// <summary>
        /// Gibt an ob Daten empfangen wurden
        /// </summary>
        public readonly bool Recieved = false;
        /// <summary>
        /// Gibt an ob Daten gesendet wurden
        /// </summary>
        public readonly bool Sent = false;
        public readonly bool Dead = false;
        public readonly DateTime Timestamp = DateTime.Now;
        /// <summary>
        /// Der Daten-Strom
        /// </summary>
        public readonly byte[] Data;
        public Connection handle;
        /// <summary>
        /// Erstellt neue Ereignisdaten
        /// </summary>
        /// <param name="Data">Empfangene oder gesendete Daten.</param>
        /// <param name="mode">True, falls Daten empfangen wurden.</param>
        public ConnectionEventArgs(byte[] Data, bool mode, Connection handle)
        {
            if (mode)
                Recieved = true;
            else
                Sent = true;
            this.Data = Data;
            this.handle = handle;
        }
        public ConnectionEventArgs(Connection handle)
        {
            Dead = true;
            this.Data = new byte[0];
            this.handle = handle;
        }
    }
    public class ConnectionWorkingThread
    {
        private bool RaiseExit = false;
        private Connection handle;
        private System.Net.Sockets.NetworkStream stream;
        private UInt32 buffersize;
        public ConnectionWorkingThread(System.Net.Sockets.NetworkStream stream, Connection handle, UInt32 buffersize)
        {
            this.stream = stream;
            this.handle = handle;
            this.buffersize = buffersize;
        }
        public void WaitTillDelimiter(object data)
        {
            char delimiter = (char)data;
            byte[] buffer = new byte[buffersize];
            byte[] ret;
            UInt32 pointer = 0;
            int j = 0;
            while (handle.socket.Connected)
            {
                while (stream.DataAvailable && !RaiseExit)
                {
                    buffer[pointer] = (byte)stream.ReadByte();
                    if ((char)buffer[pointer] == delimiter)
                    {
                        ret = new byte[pointer + 1];
                        for (int i = 0; i <= pointer; i++)
                        {
                            ret[i] = buffer[i];
                        }
                        buffer = new byte[buffersize];
                        pointer = 0;
                        handle.Invoke(new ConnectionEventArgs(ret, true, handle));
                    }
                    else if ((char)buffer[pointer] != '\0')
                    {
                        pointer++;
                    }
                }
                System.Threading.Thread.Sleep(5);
                j++;
                if (j == 100)
                {
                    try
                    {
                        handle.output.Write("\0");
                        handle.output.Flush();
                    }
                    catch
                    {
                        // while loop handles this
                    }
                    finally
                    {
                        j = 0;
                    }
                }
            }
            if (!RaiseExit) handle.Invoke(new ConnectionEventArgs(handle));
        }
        public void Stop()
        {
            RaiseExit = true;
        }
    }
}
