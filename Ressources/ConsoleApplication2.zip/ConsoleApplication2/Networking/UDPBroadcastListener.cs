using System;

namespace Server.Networking
{
    /// <summary>
    /// Eventhandler f�r eingehende Broadcastanfragen.
    /// </summary>
    /// <param name="RemoteEndpoint">Absender.</param>
    public delegate void UDPBroadcastRequest(System.Net.EndPoint RemoteEndpoint, byte[] buffer, System.Net.IPAddress Interface);
    /// <summary>
    /// Stellt einen UDP-Server zur Verf�gung, der an vorgegebenen IP-Adressen/Ports auf eingehende
    /// Broadcasts wartet und ein Event ausl�st.
    /// </summary>
    public class UDPBroadcastListener
    {
        public event UDPBroadcastRequest UDPRequest;
        System.Net.Sockets.Socket[] Sockets;
        System.Net.IPAddress[] IPAdressen;
        UInt16[] Ports;
        System.Net.IPEndPoint[] LocalEndpoints;
        public System.Threading.Thread[] Listener;
        /// <summary>
        /// Erstellt einen neuen UDP-Server.
        /// </summary>
        /// <param name="IP">IP-Adressen an die gebunden werden soll.</param>
        /// <param name="Port">Ports an die gebunden werden soll.</param>
        public UDPBroadcastListener(System.Net.IPAddress[] IP, UInt16[] Port)
        {
            IPAdressen = IP;
            Ports = Port;
            Bind();
        }
        /// <summary>
        /// Erstellt einen neuen UDP-Server.
        /// </summary>
        /// <param name="IP">IP-Adressen an die gebunden werden soll.</param>
        /// <param name="Port">Port an den gebunden werden soll.</param>
        public UDPBroadcastListener(System.Net.IPAddress[] IP, UInt16 Port)
        {
            IPAdressen = IP;
            Ports = new UInt16[] { Port };
            Bind();
        }
        /// <summary>
        /// Erstellt einen neuen UDP-Server.
        /// </summary>
        /// <param name="IP">IP-Adresse an die gebunden werden soll.</param>
        /// <param name="Port">Ports an die gebunden werden soll.</param>
        public UDPBroadcastListener(System.Net.IPAddress IP, UInt16[] Port)
        {
            IPAdressen = new System.Net.IPAddress[] { IP };
            Ports = Port;
            Bind();
        }
        /// <summary>
        /// Erstellt einen neuen UDP-Server.
        /// </summary>
        /// <param name="IP">IP-Adresse an die gebunden werden soll.</param>
        /// <param name="Port">Port an den gebunden werden soll.</param>
        public UDPBroadcastListener(System.Net.IPAddress IP, UInt16 Port)
        {
            IPAdressen = new System.Net.IPAddress[] { IP };
            Ports = new UInt16[] { Port };
            Bind();
        }
        /// <summary>
        /// Bindet alle Sockets an alle IP/Port-Kombinationen
        /// </summary>
        private void Bind()
        {
            LocalEndpoints = new System.Net.IPEndPoint[IPAdressen.Length * Ports.Length];
            int i = 0;
            foreach (System.Net.IPAddress IP in IPAdressen)
            {
                foreach (UInt16 Port in Ports)
                {
                    LocalEndpoints[i] = new System.Net.IPEndPoint(IP,Port);
                    i++;
                }
            }
        }
        /// <summary>
        /// Startet das abh�ren der Sockets und initialisiert die Arbeitsthreads.
        /// </summary>
        /// <returns>True, wenn erfolgreich.</returns>
        public bool Listen()
        {
            int i = 0;
            Sockets = new System.Net.Sockets.Socket[LocalEndpoints.Length];
            Listener = new System.Threading.Thread[LocalEndpoints.Length];
            System.Threading.ParameterizedThreadStart Handler = new System.Threading.ParameterizedThreadStart(UDPBroadcastListenerWorkingThread.Wait);
            UDPBroadcastListenerWorkingThread.Init(Sockets, this, IPAdressen);
            foreach (System.Net.IPEndPoint LocalEndpoint in LocalEndpoints)
            {
                try
                {
                    Sockets[i] = new System.Net.Sockets.Socket(LocalEndpoint.AddressFamily, System.Net.Sockets.SocketType.Dgram, System.Net.Sockets.ProtocolType.Udp);
                    Sockets[i].Bind(LocalEndpoint);
                    Sockets[i].EnableBroadcast = true;
                    Listener[i] = new System.Threading.Thread(Handler);
                    Listener[i].Start(i);
                }
                catch
                {
                    return false;
                }
                i++;
            }
            return true;
        }
        /// <summary>
        /// L�st den Eventhandler aus.
        /// </summary>
        public void Invoke(System.Net.EndPoint RemoteEndpoint, byte[] buffer, System.Net.IPAddress Interface)
        {
            if (UDPRequest != null) UDPRequest(RemoteEndpoint, buffer, Interface);
        }
    }
    public static class UDPBroadcastListenerWorkingThread
    {
        public static System.Net.IPAddress[] IPAdressen;
        /// <summary>
        /// Zu �berwachende Sockets (sollte nicht manuell geschrieben werden).
        /// </summary>
        public static System.Net.Sockets.Socket[] Socket;
        /// <summary>
        /// Handler des Listeners.
        /// </summary>
        static UDPBroadcastListener handle;
        /// <summary>
        /// Initialisieren des Threads.
        /// </summary>
        /// <param name="Sockets">Zu �berwachende Sockets.</param>
        /// <param name="handle">Handler des Listeners.</param>
        public static void Init(System.Net.Sockets.Socket[] Sockets, UDPBroadcastListener serverhandle, System.Net.IPAddress[] ips)
        {
            Socket = Sockets;
            handle = serverhandle;
            IPAdressen = ips;
        }
        public static bool RaiseExit = false;
        /// <summary>
        /// Thread-Funktion, wartet auf eingehende Anfragen und l�st den Eventhandler aus.
        /// </summary>
        /// <param name="data"></param>
        public static void Wait(object data)
        {
            int i = (int)data;
            byte[] buffer = new byte[1024];
            System.Net.IPEndPoint sender = new System.Net.IPEndPoint(System.Net.IPAddress.Any, 0);
            System.Net.EndPoint senderRemote = (System.Net.EndPoint)sender;
            Socket[i].ReceiveTimeout = 500;
            int count = 0;
            while (!RaiseExit)
            {
                try
                {
                    count = Socket[i].ReceiveFrom(buffer, ref senderRemote);
                    if (count > 0)
                    {
                        handle.Invoke(senderRemote, buffer, IPAdressen[i]);
                        // Buffer lehren
                        buffer = new byte[1024];
                    }
                }
                catch { }
                System.Threading.Thread.Sleep(25);
            }
        }
        public static void Stop()
        {
            RaiseExit = true;
        }
    }
    /// <summary>
    /// Konvertiert Byte-Arrays in Strings und umgekehrt.
    /// </summary>
    public static class Converter
    {
        public static string byte2string(byte[] data, System.Text.Encoding encoding)
        {
            return encoding.GetString(data);
        }
        public static byte[] string2byte(string data, System.Text.Encoding encoding)
        {
            return encoding.GetBytes(data);
        }
    }
}
