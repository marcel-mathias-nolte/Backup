using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Server.Networking.Protokolllogger
{
    public partial class Logwindow : Form
    {
        delegate void LogCallback(string[] text);
        public Logwindow(string[] headline)
        {
            InitializeComponent();
            Grid.ColumnCount = headline.Length;
            Grid.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Raised;
            Grid.RowHeadersVisible = false;
            for (int i = 0; i < headline.Length; i++)
            {
                Grid.Columns[i].Name = headline[i];
            }
            Grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            Grid.MultiSelect = false;
            Grid.Columns[0].Width = 250;
            Grid.Columns[1].Width = 20;
            Grid.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Grid.Columns[2].Width = 250;
            Grid.Columns[3].Width = 400;
            int width = 3;
            foreach (DataGridViewColumn c in Grid.Columns)
                width += c.Width;
            this.Width += (width - Grid.Width);
            Grid.Width = width;
            //Tray.Visible = false;
        }

        public void Log(string[] text)
        {
            // InvokeRequired required compares the thread ID of the
            // calling thread to the thread ID of the creating thread.
            // If these threads are different, it returns true.
            if (Grid.InvokeRequired)
            {
                LogCallback d = new LogCallback(Log);
                this.Invoke(d, new object[] { text });
            }
            else
            {
                Grid.Rows.Add(text);
            }
        }

        private void Tray_Click(object sender, MouseEventArgs e)
        {
            this.ShowInTaskbar = true;
            //this.Tray.Visible = false;
            this.WindowState = FormWindowState.Normal;
        }

        private void Logwindow_Minimize(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                this.Tray.ContextMenuStrip = TrayMenu;
                this.ShowInTaskbar = false;
                this.WindowState = FormWindowState.Minimized;
                //this.Tray.Visible = true;
            }
        }

        private void Restore_Click(object sender, EventArgs e)
        {
            this.ShowInTaskbar = true;
            //this.Tray.Visible = false;
            this.WindowState = FormWindowState.Normal;
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Program.RaiseExit = true;
            Tray.Visible = false;
            Tray.Dispose();
        }
        private void Logwindow_Close(object sender, FormClosedEventArgs e)
        {
            Program.RaiseExit = true;
            Tray.Visible = false;
            Tray.Dispose();
        }

        private void anzeigenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Program.Show();
        }

        private void versteckenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Program.Hide();
        }

    }
}