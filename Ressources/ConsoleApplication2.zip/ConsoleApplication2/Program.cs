using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Server.Networking;

namespace Server
{
    class Program
    {
        public static Server.Networking.Protokolllogger.Logwindow log;
        public static bool RaiseExit = false;
        public static Server.Networking.TCP.TCPServer server;
        #region HideToTray
        [DllImport("user32.dll")]
        public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
        [DllImport("user32.dll")]
        static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
        /// <summary>
        /// A handle to the console window
        /// </summary>
        public static IntPtr hWnd;
        /// <summary>
        /// Hides an Console Window
        /// </summary>
        public static void Hide()
        {
            if (hWnd != IntPtr.Zero)
                ShowWindow(hWnd, 0);
        }
        /// <summary>
        /// Shows an Console Window
        /// </summary>
        public static void Show()
        {
            if (hWnd != IntPtr.Zero)
                ShowWindow(hWnd, 1);
        }
        #endregion
        static void Main(string[] args)
        {
            #region Set up console window
            hWnd = FindWindow(null, Console.Title);
            Hide();
            Console.Title = "UDP Broadcast Listener";
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WindowHeight = 5;
            Console.Clear();
            Console.WriteLine("Running");
            #endregion
            #region Set up log window
            log = new Server.Networking.Protokolllogger.Logwindow(new string[] { "LOCAL", "<>", "REMOTE", "MESSAGE" });
            log.Show();
            Console.WriteLine("Log window started.");
            #endregion
            #region Get all local IPs
            System.Net.NetworkInformation.NetworkInterface[] nics = System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces();
            System.Net.NetworkInformation.UnicastIPAddressInformationCollection ips;
            IPAddress[] IPs = new IPAddress[0];
            foreach (System.Net.NetworkInformation.NetworkInterface nic in nics)
            {
                ips = nic.GetIPProperties().UnicastAddresses;
                foreach (System.Net.NetworkInformation.UnicastIPAddressInformation ip in ips)
                {
                    Array.Resize(ref IPs, IPs.Length + 1);
                    IPs[IPs.Length - 1] = ip.Address;
                    Console.WriteLine("BIND: TCP " + ip.Address.ToString() + ":" + Settings.TCPPort.ToString());
                }
            }
            #endregion
            #region Set up UDP Broadcast Server
            UDPBroadcastListener listener = new UDPBroadcastListener(IPs, Settings.UDPPort);
            Console.WriteLine("UDP Server started");
            foreach (IPAddress IP in IPs)
                log.Log(new string[] { "UDP:" + IP.ToString()+":" + Settings.UDPPort.ToString(), "|", "", "LISTEN" });
            listener.UDPRequest += new UDPBroadcastRequest(request);
            listener.Listen();
            #endregion
            #region Bind TCP-Server on all local adresses
            #region Start TCP Server
            server = new Server.Networking.TCP.TCPServer();
            server.ConnectionAccepted += new Server.Networking.TCP.TCPServerConnEvent(TCPConnectionAccepted);
            server.ServerStarted += new Server.Networking.TCP.TCPServerEvent(TCPServerStarted);
            Server.Networking.TCP.ConnectionHandler.DataRecieved += new Server.Networking.TCP.TCPDataEvent(TCPDataRecieved);
            Server.Networking.TCP.ConnectionHandler.DataSent += new Server.Networking.TCP.TCPDataEvent(TCPDataSent);
            Server.Networking.TCP.ConnectionHandler.ConnectionLost += new Server.Networking.TCP.TCPDataEvent(TCPConnectionLost);
            Server.Networking.TCP.ConnectionHandler.ConnectionAdded += new Server.Networking.TCP.ConnectionEvent(TCPConnectionAdded);
            server.Start(IPs, Settings.TCPPort);
            Console.WriteLine("TCP Server started.");
            #endregion
            #endregion
            while (!RaiseExit)
            {
                System.Threading.Thread.Sleep(20);
                Application.DoEvents();
            }
            #region AppExit
            Show();
            Console.WriteLine("Stopping TCP Server ...");
            server.Stop();
            Console.WriteLine("Closing connections ...");
            Server.Networking.TCP.ConnectionHandler.Stop();
            // stop working threads
            Console.WriteLine("Stopping UDP worker threads ...");
            Server.Networking.UDPBroadcastListenerWorkingThread.Stop();
            System.Threading.Thread.Sleep(200);
            Console.WriteLine("Killing hanging threads ...");
            //kill hanging threads
            foreach (System.Threading.Thread t in listener.Listener)
            {
                if (t != null) t.Abort();
                if (t != null) t.Join();
            }
            // dispose threads
            listener.Listener = new System.Threading.Thread[0];
            // exit application
            Application.Exit();
            #endregion
        }
        /// <summary>
        /// Handles incoming UDP Broadcast requests
        /// </summary>
        public static void request(EndPoint Remote, byte[] data, IPAddress Interface)
        {
            string Request = Converter.byte2string(data, Encoding.ASCII);
            if (Request.Length >= Settings.DiscoveryString.Length && Request.Trim().Substring(0, Settings.DiscoveryString.Length) == Settings.DiscoveryString)
            {
                Socket socket = new Socket(Remote.AddressFamily, SocketType.Dgram, ProtocolType.Udp);
                string answer = Settings.AcknowledgeString.Replace("%ip%", Interface.ToString()).Replace("%port%", Settings.TCPPort.ToString());
                log.Log(new string[] { "UDP:" + Interface.ToString() + ":" + Settings.UDPPort.ToString(), "<<", "UDP:" + Remote.ToString(), Request.Trim('\0') });
                socket.SendTo(Converter.string2byte(answer, Encoding.Unicode), Remote);
                log.Log(new string[] { "UDP:" + Interface.ToString() + ":" + Settings.UDPPort.ToString(), ">>", "UDP:" + Remote.ToString(), answer });
            }
            else
            {
                log.Log(new string[] { "UDP:" + Interface.ToString() + ":" + Settings.UDPPort.ToString(), "<<", "UDP:" + Remote.ToString(), "INVALID REQ: " + Request });
            }
        }
        #region TCP Events
        public static void TCPConnectionAccepted(System.Net.Sockets.TcpClient c)
        {
            System.Net.IPEndPoint lo = (System.Net.IPEndPoint) c.Client.LocalEndPoint;
            System.Net.IPEndPoint re = (System.Net.IPEndPoint) c.Client.RemoteEndPoint;
            log.Log(new string[] { "TCP:" + lo.Address.ToString() + ":" + lo.Port.ToString(), "<<", "TCP:" + re.Address.ToString() + ":" + re.Port.ToString(), "CLIENT CONNECTED" });
            Server.Networking.TCP.ConnectionHandler.Add(c);
        }
        public static void TCPServerStarted(Server.Networking.TCP.TCPServerEventArgs e)
        {
            System.Net.IPEndPoint lo = (System.Net.IPEndPoint)server.Worker[e.index].Socket.LocalEndpoint;
            log.Log(new string[] { "TCP:" + lo.Address.ToString() + ":" + lo.Port.ToString(), "|", "", "LISTEN" });
        }
        public static void TCPConnectionLost(Server.Networking.TCP.ConnectionEventArgs e)
        {
            System.Net.IPEndPoint lo = (System.Net.IPEndPoint)e.handle.socket.Client.LocalEndPoint;
            System.Net.IPEndPoint re = (System.Net.IPEndPoint)e.handle.socket.Client.RemoteEndPoint;
            Server.Networking.TCP.ConnectionHandler.Remove(e.handle.id);
            log.Log(new string[] { "TCP:" + lo.Address.ToString() + ":" + lo.Port.ToString(), "<<", "TCP:" + re.Address.ToString() + ":" + re.Port.ToString(), "CLIENT DISCONNECTED" });
        }
        public static void TCPConnectionAdded(Server.Networking.TCP.ConnectionHandle c)
        {
            log.Log(new string[] { "TCP:" + c.LocalIP.ToString() + ":" + c.LocalPort.ToString(), ">>", "TCP:" + c.RemoteIP.ToString() + ":" + c.RemotePort.ToString(), "C# EHLO" });
            c.Socket.Write("C# EHLO\r\n");
        }
        public static void TCPDataRecieved(Server.Networking.TCP.ConnectionEventArgs e)
        {
            string request = System.Text.Encoding.ASCII.GetString(e.Data).Trim('\0').Trim().Replace("  ", " ");
            string[] requestargs = request.ToLower().Split(' ');
            #region Logging
            System.Net.IPEndPoint lo = (System.Net.IPEndPoint)e.handle.socket.Client.LocalEndPoint;
            System.Net.IPEndPoint re = (System.Net.IPEndPoint)e.handle.socket.Client.RemoteEndPoint;
            log.Log(new string[] { "TCP:" + lo.Address.ToString() + ":" + lo.Port.ToString(), "<<", "TCP:" + re.Address.ToString() + ":" + re.Port.ToString(), request });
            #endregion
            if (requestargs[0] != "c#" || requestargs.Length < 2)
            {
                e.handle.Write("C# ERRMSG 000 INVALID SYNTAX\r\n");
                return;
            }
            switch (requestargs[1])
            {
                case "ehlo":
                    e.handle.Write("HALLO!\r\n");
                    break;
            }
        }
        public static void TCPDataSent(Server.Networking.TCP.ConnectionEventArgs e)
        {
            string request = System.Text.Encoding.ASCII.GetString(e.Data).Trim('\0').Trim().Replace("  ", " ");
            #region Logging
            System.Net.IPEndPoint lo = (System.Net.IPEndPoint)e.handle.socket.Client.LocalEndPoint;
            System.Net.IPEndPoint re = (System.Net.IPEndPoint)e.handle.socket.Client.RemoteEndPoint;
            log.Log(new string[] { "TCP:" + lo.Address.ToString() + ":" + lo.Port.ToString(), ">>", "TCP:" + re.Address.ToString() + ":" + re.Port.ToString(), request });
            #endregion
        }
        #endregion
    }
    public static class Settings
    {
        public static UInt16 UDPPort = 12345;
        public static UInt16 TCPPort = 12345;
        public static string DiscoveryString = "C# DISCOVERY";
        public static string AcknowledgeString = "C# ACKNOLEDGE %ip%:%port%";
    }
}
