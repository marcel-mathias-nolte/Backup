﻿/* Copyright (c) 2008-2012 Peter Palotas, Alexandr Normuradov
 *  
 *  Permission is hereby granted, free of charge, to any person obtaining a copy 
 *  of this software and associated documentation files (the "Software"), to deal 
 *  in the Software without restriction, including without limitation the rights 
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell 
 *  copies of the Software, and to permit persons to whom the Software is 
 *  furnished to do so, subject to the following conditions:
 *  
 *  The above copyright notice and this permission notice shall be included in 
 *  all copies or substantial portions of the Software.
 *  
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
 *  THE SOFTWARE. 
 */
using System;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.InteropServices;

namespace Alphaleonis.Win32
{
   #region OSVersionName enum

   /// <summary>Enumeration used to discriminate between the named windows versions.</summary>
   /// <remarks>The values of the enumeration are ordered so a later released operating system version has a higher number, so comparisons between named versions are meaningful.</remarks>
   internal enum OSVersionName
   {
      /// <summary>A windows version earlier than Windows 2000.</summary>
      Earlier = -1,

      /// <summary>Windows 2000 (Server or Professional)</summary>
      Windows2000 = 0,

      /// <summary>Windows XP</summary>
      WindowsXP = 1,

      /// <summary>Windows Server 2003</summary>
      WindowsServer2003 = 2,

      /// <summary>Windows Vista</summary>
      WindowsVista = 3,

      /// <summary>Windows Server 2008</summary>
      WindowsServer2008 = 4,

      /// <summary>Windows 7</summary>
      Windows7 = 5,

      /// <summary>Windows Server 2008 R2</summary>
      WindowsServer2008R2 = 6,

      /// <summary>Windows 8</summary>
      Windows8 = 7,

      /// <summary>Windows Server 2012</summary>
      WindowsServer2012 = 8,

      /// <summary>A Windows version later than Windows Server 2008R2.</summary>
      Later = 0xffff
   }

   #endregion // OSVersionName enum

   #region ProcessorArchitecture enum

   /// <summary>Enumeration used by <see cref="OperatingSystemInfo"/> to indicate the current processor architecture for which the operating system is targeted and running.</summary>
   [SuppressMessage("Microsoft.Design", "CA1028:EnumStorageShouldBeInt32")]
   internal enum ProcessorArchitecture : ushort
   {
      /// <summary>PROCESSOR_ARCHITECTURE_INTEL - The system is running a 32-bit version of Windows.</summary>
      X86 = 0x00,

      /// <summary>PROCESSOR_ARCHITECTURE_IA64 - The system is running an Itanium processor.</summary>
      IA64 = 0x06,

      /// <summary>PROCESSOR_ARCHITECTURE_AMD64 - The system is running a 64-bit version of Windows.</summary>
      X64 = 0x09,

      /// <summary>PROCESSOR_ARCHITECTURE_UNKNOWN - Unknown architecture.</summary>
      Unknown = 0xFFFF,
   }

   #endregion // ProcessorArchitecture enum

   /// <summary>Static class providing access to information about the operating system under which the assembly is executing.</summary>
   internal static class OperatingSystemInfo
   {
      #region Public Properties

      #region IsServer

      /// <summary>Gets a value indicating whether the operating system is a server os.</summary>
      /// <value><c>true</c> if the current operating system is a server os; otherwise, <c>false</c>.</value>
      public static bool IsServer
      {
         get
         {
            if (_servicePackVersion == null)
               UpdateData();
            return _isServer;
         }
      }

      #endregion // IsServer

      #region OSVersion

      /// <summary>Gets the numeric version of the operating system. This is the same as returned by <see cref="System.Environment.OSVersion"/>.</summary>
      /// <value>The numeric version of the operating system.</value>
      public static Version OSVersion
      {
         get { return OsVersion; }
      }

      #endregion // OSVersion

      #region OSVersionName

      /// <summary>Gets the named version of the operating system.</summary>
      /// <value>The named version of the operating system.</value>
      public static OSVersionName OSVersionName
      {
         get
         {
            if (_servicePackVersion == null)
               UpdateData();
            return _osVersionName;
         }
      }

      #endregion // OSVersionName

      #region ProcessorArchitecture

      /// <summary>Gets the processor architecture for which the operating system is targeted.</summary>
      /// <value>The processor architecture for which the operating system is targeted.</value>
      /// <remarks>If running under WOW64 this will return a 32-bit processor. Use <see cref="IsWow64Process"/> to determine if this is the case.</remarks>
      public static ProcessorArchitecture ProcessorArchitecture
      {
         get
         {
            if (_servicePackVersion == null)
               UpdateData();
            return _processorArchitecture;
         }
      }

      #endregion // ProcessorArchitecture

      #region ServicePackVersion

      /// <summary>Gets the version of the service pack currently installed on the operating system.</summary>
      /// <value>The version of the service pack currently installed on the operating system.</value>
      /// <remarks>Only the <see cref="Version.Major"/> and <see cref="Version.Minor"/> fields are used.</remarks>
      public static Version ServicePackVersion
      {
         get
         {
            if (_servicePackVersion == null)
               UpdateData();
            return _servicePackVersion;
         }
      }

      #endregion // ServicePackVersion

      #endregion // Public Properties

      #region Public Methods

      #region IsAtLeast

      /// <summary>Determines whether the operating system is of the specified version or later.</summary>
      /// <param name="version">The lowest version for which to return <c>true</c>.</param>
      /// <returns><c>true</c> if the operating system is of the specified <paramref name="version"/> or later; otherwise, <c>false</c>.</returns>      
      public static bool IsAtLeast(OSVersionName version)
      {
         return OSVersionName >= version;
      }

      /// <summary>Determines whether operating system is of the specified version or later, allowing specification of a minimum service pack that must be installed on the lowest version.</summary>
      /// <param name="version">The minimum required version.</param>
      /// <param name="servicePackVersion">The major version of the service pack that must be installed on the minimum required version to return <c>true</c>. This can be 0 to indicate that no service pack is required.</param>
      /// <returns><c>true</c> if the operating system matches the specified <paramref name="version"/> with the specified service pack, or if the operating system is of a later version; otherwise, <c>false</c>.</returns>      
      public static bool IsAtLeast(OSVersionName version, int servicePackVersion)
      {
         return IsAtLeast(version) && ServicePackVersion.Major >= servicePackVersion;
      }

      #endregion // IsAtLeast

      #region IsWow64Process

      /// <summary>Determines whether the current process is running under WOW64.</summary>
      /// <returns><c>true</c> if the current process is running under WOW64; otherwise, <c>false</c>.</returns>      
      public static bool IsWow64Process()
      {
         IntPtr processHandle = Process.GetCurrentProcess().Handle;
         bool value;
         if (!NativeMethods.IsWow64Process(processHandle, out value))
            Marshal.ThrowExceptionForHR(Marshal.GetLastWin32Error());
         return value;
      }

      #endregion // IsWow64Process

      #endregion // Public Methods

      #region Private members

      private static void UpdateData()
      {
         NativeMethods.OSVersionInfoEx verInfo = new NativeMethods.OSVersionInfoEx();
         verInfo.OSVersionInfoSize = Marshal.SizeOf(verInfo);

         NativeMethods.SystemInfo sysInfo = new NativeMethods.SystemInfo();

         NativeMethods.GetSystemInfo(ref sysInfo);
         if (!NativeMethods.GetVersionEx(ref verInfo))
            NativeError.ThrowException();

         Debug.Assert(verInfo.MajorVersion == Environment.OSVersion.Version.Major);
         Debug.Assert(verInfo.MinorVersion == Environment.OSVersion.Version.Minor);
         Debug.Assert(verInfo.BuildNumber == Environment.OSVersion.Version.Build);

         _processorArchitecture = (ProcessorArchitecture) sysInfo.processorArchitecture;
         _servicePackVersion = new Version(verInfo.ServicePackMajor, verInfo.ServicePackMinor);
         _isServer = verInfo.ProductType == NativeMethods.VerNtDomainController ||
                     verInfo.ProductType == NativeMethods.VerNtServer;


         // http://msdn.microsoft.com/en-us/library/windows/desktop/ms724833%28v=vs.85%29.aspx

         // The following table summarizes the most recent operating system version numbers.
         //    Operating system	            Version number    Other
         // ================================================================================
         //    Windows 8	                  6.2               OSVersionInfoEx.ProductType == VerNtWorkstation
         //    Windows Server 2012	         6.2               OSVersionInfoEx.ProductType != VerNtWorkstation
         //    Windows 7	                  6.1               OSVersionInfoEx.ProductType == VerNtWorkstation
         //    Windows Server 2008 R2	      6.1               OSVersionInfoEx.ProductType != VerNtWorkstation
         //    Windows Server 2008	         6.0               OSVersionInfoEx.ProductType != VerNtWorkstation  
         //    Windows Vista	               6.0               OSVersionInfoEx.ProductType == VerNtWorkstation
         //    Windows Server 2003 R2	      5.2               GetSystemMetrics(SM_SERVERR2) != 0
         //    Windows Home Server  	      5.2               OSVersionInfoEx.SuiteMask & VER_SUITE_WH_SERVER
         //    Windows Server 2003           5.2               GetSystemMetrics(SM_SERVERR2) == 0
         //    Windows XP 64-Bit Edition     5.2               (OSVersionInfoEx.ProductType == VerNtWorkstation) && (SystemInfo.ProcessorArchitecture == ProcessorArchitecture.X64)
         //    Windows XP	                  5.1               Not applicable
         //    Windows 2000	               5.0               Not applicable


         if (verInfo.MajorVersion > 6)
            _osVersionName = OSVersionName.Later;

         else
            switch (verInfo.MajorVersion)
            {
                  #region Version 6

               case 6:
                  switch (verInfo.MinorVersion)
                  {
                        // Windows Vista or Windows Server 2008
                     case 0:
                        _osVersionName = (verInfo.ProductType == NativeMethods.VerNtWorkstation)
                                            ? OSVersionName.WindowsVista
                                            : OSVersionName.WindowsServer2008;
                        break;

                        // Windows 7 or Windows Server 2008 R2
                     case 1:
                        _osVersionName = (verInfo.ProductType == NativeMethods.VerNtWorkstation)
                                            ? OSVersionName.Windows7
                                            : OSVersionName.WindowsServer2008R2;
                        break;

                        // Windows 8 or Windows Server 2012
                     case 2:
                        _osVersionName = (verInfo.ProductType == NativeMethods.VerNtWorkstation)
                                            ? OSVersionName.Windows8
                                            : OSVersionName.WindowsServer2012;
                        break;

                     default:
                        _osVersionName = OSVersionName.Later;
                        break;
                  }
                  break;

                  #endregion // Version 6

                  #region Version 5

               case 5:
                  switch (verInfo.MinorVersion)
                  {
                     case 0:
                        _osVersionName = OSVersionName.Windows2000;
                        break;

                     case 1:
                        _osVersionName = OSVersionName.WindowsXP;
                        break;

                     case 2:
                        _osVersionName = (verInfo.ProductType == NativeMethods.VerNtWorkstation &&
                                          _processorArchitecture == ProcessorArchitecture.X64)
                                            ? OSVersionName.WindowsXP
                                            : (verInfo.ProductType != NativeMethods.VerNtWorkstation)
                                                 ? OSVersionName.WindowsServer2003
                                                 : OSVersionName.Later;
                        break;

                     default:
                        _osVersionName = OSVersionName.Later;
                        break;
                  }
                  break;

                  #endregion // Version 5

               default:
                  _osVersionName = OSVersionName.Earlier;
                  break;
            }
      }

      private static OSVersionName _osVersionName = OSVersionName.Later;
      private static readonly Version OsVersion = Environment.OSVersion.Version;
      private static Version _servicePackVersion;
      private static ProcessorArchitecture _processorArchitecture;
      private static bool _isServer;

      #endregion // Private members

      #region P/Invoke members

      private static class NativeMethods
      {
         [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
         public struct OSVersionInfoEx
         {
            public int OSVersionInfoSize;
            public readonly int MajorVersion;
            public readonly int MinorVersion;
            public readonly int BuildNumber;
            public readonly int PlatformId;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public readonly string CSDVersion;
            public readonly UInt16 ServicePackMajor;
            public readonly UInt16 ServicePackMinor;
            public readonly UInt16 SuiteMask;
            public readonly byte ProductType;
            public readonly byte Reserved;
         }

         [StructLayout(LayoutKind.Sequential)]
         public struct SystemInfo
         {
            public readonly ushort processorArchitecture;
            readonly ushort reserved;
            public readonly uint pageSize;
            public readonly IntPtr minimumApplicationAddress;
            public readonly IntPtr maximumApplicationAddress;
            public readonly IntPtr activeProcessorMask;
            public readonly uint numberOfProcessors;
            public readonly uint processorType;
            public readonly uint allocationGranularity;
            public readonly ushort processorLevel;
            public readonly ushort processorRevision;
         }

         public const short VerNtWorkstation = 1;
         public const short VerNtDomainController = 2;
         public const short VerNtServer = 3;

         /// <summary>Retrieves information about the current operating system.</summary>
         /// <returns>
         /// If the function succeeds, the return value is a nonzero value.
         /// If the function fails, the return value is zero. To get extended error information, call GetLastError. The function fails if you specify an invalid value for the dwOSVersionInfoSize member of the OSVERSIONINFO or OSVERSIONINFOEX structure.
         /// </returns>
         /// <remarks>Minimum supported client: Windows 2000 Professional</remarks>
         /// <remarks>Minimum supported server: Windows 2000 Server</remarks>
         [SuppressMessage("Microsoft.Security", "CA5122:PInvokesShouldNotBeSafeCriticalFxCopRule")]
         [SuppressMessage("Microsoft.Usage", "CA2205:UseManagedEquivalentsOfWin32Api")]
         [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode, EntryPoint = "GetVersionExW")]
         [return: MarshalAs(UnmanagedType.Bool)]
         public static extern bool GetVersionEx(ref OSVersionInfoEx osvi);

         /// <summary>Retrieves information about the current system.</summary>
         /// <returns>This function does not return a value.</returns>
         /// <remarks>Minimum supported client: Windows 2000 Professional</remarks>
         /// <remarks>Minimum supported server: Windows 2000 Server</remarks>
         [SuppressMessage("Microsoft.Security", "CA5122:PInvokesShouldNotBeSafeCriticalFxCopRule")]
         [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
         public static extern void GetSystemInfo(ref SystemInfo lpSystemInfo);

         /// <summary>Determines whether the specified process is running under WOW64.</summary>
         /// <returns>
         /// If the function succeeds, the return value is a nonzero value.
         /// If the function fails, the return value is zero. To get extended error information, call GetLastError.
         /// </returns>
         /// <remarks>Minimum supported client: Windows Vista, Windows XP with SP2</remarks>
         /// <remarks>Minimum supported server: Windows Server 2008, Windows Server 2003 with SP1</remarks>
         [SuppressMessage("Microsoft.Security", "CA5122:PInvokesShouldNotBeSafeCriticalFxCopRule")]
         [DllImport("kernel32.dll", SetLastError = true, CallingConvention = CallingConvention.Winapi)]
         [return: MarshalAs(UnmanagedType.Bool)]
         public static extern bool IsWow64Process([In] IntPtr hProcess, [Out, MarshalAs(UnmanagedType.Bool)] out bool lpSystemInfo);
      }

      #endregion // P/Invoke members
   }
}