﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LCARS
{
    public partial class Calendar : UserControl
    {
        public Calendar()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint, true);
        }

        private void Calendar_Paint(object sender, PaintEventArgs e)
        {
            try
            {
                e.Graphics.FillRectangle(new SolidBrush(this.BackColor), e.ClipRectangle);
                int i;
                float x = (e.ClipRectangle.Width - 1) / 2;
                float y = (e.ClipRectangle.Height - 1) / 2;
                float r = default(float);
                Pen p = new Pen(Color.Yellow);
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                e.Graphics.DrawEllipse(p, new Rectangle(e.ClipRectangle.Location, new Size(e.ClipRectangle.Width - 1, e.ClipRectangle.Height - 1)));
                for (i = 0; i < 360; i += 6)
                {
                    r = (i % 30 == 0) ? x / 6 : x / 10;
                    e.Graphics.DrawLine(p, x + x * (float)Math.Cos(i * Math.PI / 180), y + y * (float)Math.Sin(i * Math.PI / 180), x + (x - r) * (float)Math.Cos(i * Math.PI / 180), y + (y - r) * (float)Math.Sin(i * Math.PI / 180));
                }
                //Stundenzeiger
                i = DateTime.Now.Hour * 360 / 12 - 90 + DateTime.Now.Minute * 30 / 60;
                p.Width = 5;
                p.Color = Color.Red;
                e.Graphics.DrawLine(p, x + x/2 * (float)Math.Cos(i * Math.PI / 180), y + y/2 * (float)Math.Sin(i * Math.PI / 180), x, y);
                //Stundenzeiger
                i = DateTime.Now.Minute * 360 / 60 - 90;
                p.Width = 3;
                p.Color = Color.Red;
                e.Graphics.DrawLine(p, x + x * 3 / 4 * (float)Math.Cos(i * Math.PI / 180), y + y * 3 / 4 * (float)Math.Sin(i * Math.PI / 180), x, y);
                //Sekundenzeiger
                i = DateTime.Now.Second * 360 / 60 - 90;
                p.Width = 1;
                p.Color = Color.Red;
                e.Graphics.DrawLine(p, x + x * (float)Math.Cos(i * Math.PI / 180), y + y * (float)Math.Sin(i * Math.PI / 180), x, y);
            }
            catch
            {
            }
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x00000020;
                return cp;
            }
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            // dont code anything here. Leave blank
        }

        protected void InvalidateEx()
        {
            if (Parent == null)
                return;
            Rectangle rc = new Rectangle(this.Location, this.Size);
            Parent.Invalidate(rc, true);
        }
    }
}
