This directory contains two classes that might be useful to anyone 
looking to use the AlphaVSS libraries to manage shadow copies. 

The sample is limited to the most basic VSS functionality, 
though some more advanced approaches are considered in the comments.

See the comments in the source code and accompanying help-file for more information.

To compile the source code you also need to get and reference 
AlphaFS, freely available from http://alphafs.codeplex.com/

A big thanks to Jay Miller for supplying the sample code and allowing
the redistribution of it together with AlphaVSS.