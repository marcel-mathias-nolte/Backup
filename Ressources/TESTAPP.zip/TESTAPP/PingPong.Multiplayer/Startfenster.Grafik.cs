using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PingPong.Multiplayer
{
    public partial class Startfenster : Form
    {
        public void Zeichnen(object s, PaintEventArgs e)
        {

        }
        public void Zeichnen()
        {
            Zeichnen(this, new PaintEventArgs(this.CreateGraphics(), this.ClientRectangle));
        }
    }
}
