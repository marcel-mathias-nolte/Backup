using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Text;
using Nolte.Net;

namespace PingPong.Multiplayer
{
    /// <summary>
    /// Globale Einstellungen/Variablen
    /// </summary>
    public static class Global
    {
        /// <summary>
        /// Die TCP-Verbindung zum Gegenspieler
        /// </summary>
        public static ClientInfo Verbindung;

        /// <summary>
        /// Punkte der Spieler
        /// </summary>
        public static int PunkteA, PunkteB;

        /// <summary>
        /// Position der Paddel
        /// </summary>
        public static int PosA, PosB;

        /// <summary>
        /// Startmodus des aktuellen Spiels
        /// </summary>
        public static StartModus Modus;
    }

    public enum StartModus : int
    {
        Server, Client
    }
}
