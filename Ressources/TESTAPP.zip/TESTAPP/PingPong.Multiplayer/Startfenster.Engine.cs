using System;
using System.Collections.Generic;
using System.Text;

namespace PingPong.Multiplayer
{
    public partial class Startfenster
    {
        void StartGame()
        {
            btn_CreateGame.Visible = false;
            btn_SearchGame.Visible = false;
            Global.PosA = this.ClientSize.Height / 2;
            Global.PosB = this.ClientSize.Height / 2;
            Global.PunkteA = 0;
            Global.PunkteB = 0;
        }
    }
}
