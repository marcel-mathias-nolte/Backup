using Nolte.Net;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace PingPong.Multiplayer
{
    public partial class Startfenster : Form
    {

        public Startfenster()
        {
            InitializeComponent();
            BackgroundImageLayout = ImageLayout.Stretch;
            BackgroundImage = Properties.Resources.Hintergrund;
        }

        /// <summary>
        /// Lokalen Spielserver starten
        /// </summary>
        private void btn_CreateGame_Click(object sender, EventArgs e)
        {
            // Benutzerinteraktion verbieten
            btn_CreateGame.Enabled = false;
            btn_SearchGame.Enabled = false;
            // Severdialog zeigen
            GameServerDialog Dialog = new GameServerDialog("Spiel erstellen", 10999, 2);
            DialogResult Ergebnis = Dialog.ShowDialog();
            if (Ergebnis == DialogResult.OK && 
                Dialog.connections.Count > 0 && 
                Dialog.connections[0].Connection != null &&
                Dialog.connections[0].Connection.Connected)
            {
               // Dialog abgeschlossen und Verbindung aktiv
                Global.Verbindung = Dialog.connections[0];
                Global.Modus = StartModus.Server;
                StartGame();
            }
            else
            {
                // Benutzer hat Dialog abgebrochen
                btn_CreateGame.Enabled = true;
                btn_SearchGame.Enabled = true;
            }
        }

        private void Startfenster_Resize(object sender, EventArgs e)
        {
            if (this.WindowState != FormWindowState.Normal)
                this.WindowState = FormWindowState.Normal;
        }
    }
}