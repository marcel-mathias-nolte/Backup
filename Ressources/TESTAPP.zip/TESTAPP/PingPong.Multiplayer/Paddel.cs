using System;
using System.Collections.Generic;
using System.Text;

namespace PingPong.Multiplayer
{
    /// <summary>
    /// Ein Paddel
    /// </summary>
    public class Paddel
    {
        Spieler spieler;
        float EinProzent;

        public Paddel(Spieler spieler)
        {
            this.spieler = spieler;
            EinProzent = (spieler == Spieler.A) ? (float)Global.PosA / 50f : (float)Global.PosB / 50f;
        }

        public void BewegenZu(float percent)
        {
            if (spieler == Spieler.A)
            {
                Global.PosA = (int)(EinProzent * percent);
            }
            else
            {
                Global.PosB = (int)(EinProzent * percent);
            }
        }
    }

    public enum Spieler : int
    {
        A, B
    }


}
