﻿namespace PingPong.Multiplayer
{
    partial class Startfenster
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_CreateGame = new System.Windows.Forms.Button();
            this.btn_SearchGame = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_CreateGame
            // 
            this.btn_CreateGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CreateGame.Location = new System.Drawing.Point(12, 12);
            this.btn_CreateGame.Name = "btn_CreateGame";
            this.btn_CreateGame.Size = new System.Drawing.Size(374, 426);
            this.btn_CreateGame.TabIndex = 0;
            this.btn_CreateGame.Text = "SPIEL ERSTELLEN";
            this.btn_CreateGame.UseVisualStyleBackColor = true;
            this.btn_CreateGame.Click += new System.EventHandler(this.btn_CreateGame_Click);
            // 
            // btn_SearchGame
            // 
            this.btn_SearchGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SearchGame.Location = new System.Drawing.Point(392, 12);
            this.btn_SearchGame.Name = "btn_SearchGame";
            this.btn_SearchGame.Size = new System.Drawing.Size(374, 426);
            this.btn_SearchGame.TabIndex = 1;
            this.btn_SearchGame.Text = "SPIEL SUCHEN";
            this.btn_SearchGame.UseVisualStyleBackColor = true;
            // 
            // Startfenster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(780, 450);
            this.Controls.Add(this.btn_SearchGame);
            this.Controls.Add(this.btn_CreateGame);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Startfenster";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PingPong Multiplayer";
            this.TopMost = true;
            this.TransparencyKey = System.Drawing.Color.Red;
            this.Resize += new System.EventHandler(this.Startfenster_Resize);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_CreateGame;
        private System.Windows.Forms.Button btn_SearchGame;
    }
}