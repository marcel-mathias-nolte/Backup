using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Nolte.Net
{
    internal delegate void NewClientConnection(object sender, NewClientConnectionEventArgs e);

    internal class NewClientConnectionEventArgs : EventArgs
    {
        public TcpClient Connection;

        public NewClientConnectionEventArgs(TcpClient Connection)
        {
            this.Connection = Connection;
        }
    }

    internal class TCPServer
    {
        Thread workerThread;
        TcpListener server;
        volatile bool stopThread;
        int port;
        volatile int realport;

        internal event NewClientConnection ClientConnected;

        internal void OnClientConnect(TcpClient Connection)
        {
            ClientConnected(this, new NewClientConnectionEventArgs(Connection));
        }

        internal TCPServer(int TCPPort)
        {
            workerThread = new Thread(new ThreadStart(Worker));
            stopThread = false;
            port = TCPPort;
        }

        internal void Start()
        {
            server = new TcpListener(IPAddress.Any, port);
            server.Start();
            realport = ((IPEndPoint)server.LocalEndpoint).Port;

            workerThread.Start();
            ThreadHandler.Add(workerThread);

        }

        internal void Stop()
        {
            stopThread = true;
            Thread.Sleep(60);
            if (workerThread.ThreadState != ThreadState.Stopped)
                workerThread.Abort();
        }

        internal void Worker()
        {
            while (!stopThread)
            {
                if (server.Pending())
                {
                    OnClientConnect(server.AcceptTcpClient());
                }
                Thread.Sleep(30);
            }
            stopThread = false;
            server.Stop();
        }

        public int Port
        {
            get
            {
                return realport;
            }
        }

    }

}
