using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Nolte.Net
{
    public struct ClientInfo
    {
        public IPAddress IP;
        public int Port;
        public TcpClient Connection;
        public StreamReader Reader;
        public StreamWriter Writer;

        public string Username;
        public string Hostname;
    }

    public partial class GameServerDialog : Form
    {
        delegate void AddConnection(ClientInfo ci);
        AddConnection addConnection;
        AddConnection removeConnection;
        int port, udpport, maxconnections;
        string magicWord = Application.ProductName;
        TCPServer server;
        UdpBroadcaster broadcaster;
        public List<ClientInfo> connections;
        volatile bool StopKeepAlive = false;

        public GameServerDialog(string Title, ushort Port, ushort UDPPort, int MaxConnections)
        {
            Setup(Title, (int)Port, (int)UDPPort, MaxConnections);
        }
        public GameServerDialog(string Title, ushort UDPPort, int MaxConnections)
        {
            Setup(Title, 0, (int)UDPPort, MaxConnections);
        }
        private void Setup(string Title, int Port, int UDPPort, int MaxConnections)
        {
            InitializeComponent();
            Text = Title;
            port = Port;
            udpport = UDPPort;
            for (int i = 2; i <= MaxConnections; i++)
                comboBox1.Items.Add(i);
            comboBox1.SelectedIndex = 0;
            connections = new List<ClientInfo>();
            addConnection = new AddConnection(HandleClientConnection);
            removeConnection = new AddConnection(RemoveClientConnection);
            Thread t = new Thread(new ThreadStart(KeepAlive));
            ThreadHandler.Add(t);
        }

        internal void KeepAlive()
        {
            do
            {
                foreach (ClientInfo ci in connections)
                {
                    try
                    {
                        ci.Writer.WriteLine();
                        ci.Writer.Flush();
                        if (!ci.Connection.Connected)
                        {
                            this.Invoke(removeConnection, new object[] { ci });
                        }
                    }
                    catch
                    {
                        this.Invoke(removeConnection, new object[] { ci });
                    }
                }
                Thread.Sleep(50);
            }
            while (!StopKeepAlive);
        }

        internal void ClientConnected(object sender, NewClientConnectionEventArgs e)
        {
            Thread t = new Thread(new ParameterizedThreadStart(HandleConnectionAttempt));
            ThreadHandler.Add(t);
            t.Start(e.Connection);
        }

        internal void RemoveClientConnection(ClientInfo ci)
        {
            connections.Remove(ci);
            listBox1.Items.Remove(ci.Username + " @ " + ci.Hostname);
        }

        internal void HandleClientConnection(ClientInfo ci)
        {
            connections.Add(ci);
            listBox1.Items.Add(ci.Username + " @ " + ci.Hostname);
            if (connections.Count == maxconnections)
            {
                this.DialogResult = DialogResult.OK;
                StopKeepAlive = true;
                broadcaster.Stop();
                server.Stop();
                ThreadHandler.KillAll();
                Close();
            }
        }

        internal void HandleConnectionAttempt(object Connection)
        {
            TcpClient connection = (TcpClient)Connection;
            if (connections.Count < Thread.VolatileRead(ref maxconnections))
            {
                string[] t;
                bool run = true;
                ClientInfo ci = new ClientInfo();
                ci.Connection = connection;
                ci.Reader = new StreamReader(connection.GetStream());
                ci.Writer = new StreamWriter(connection.GetStream());
                ci.IP = ((IPEndPoint)(connection.Client.RemoteEndPoint)).Address;
                ci.Port = ((IPEndPoint)(connection.Client.RemoteEndPoint)).Port;
                ci.Hostname = Dns.GetHostEntry(ci.IP).HostName;

                ci.Writer.WriteLine("EHLO");
                ci.Writer.Flush();
                do
                {
                    t = ci.Reader.ReadLine().Split(' ');
                    switch (t[0])
                    {
                        case "EHLO":
                            ci.Writer.WriteLine("GET USERNAME");
                            ci.Writer.Flush();
                            break;
                        case "USERNAME":
                            ci.Username = (t.Length > 1 && t[1].Trim().Length > 0) ? t[1].Trim() : "Anonymous";
                            if (connections.Count < Thread.VolatileRead(ref maxconnections))
                            {
                                ci.Writer.WriteLine("READY");
                                ci.Writer.Flush();
                                this.Invoke(addConnection, new object[] { ci });
                            }
                            else
                                run = false;
                            break;
                    }
                }
                while (run);
            }
        }

        /// <summary>
        /// Get/Set the unique identifier for data packages (at least 4 chars)
        /// </summary>
        public string MagicWord
        {
            get { return magicWord; }
            set { if (value.Length > 3) magicWord = value; }
        }

        private void btnAbort_Click(object sender, EventArgs e)
        {
            ClearConnections();
            server.Stop();
            broadcaster.Stop();
            this.Close();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            string gamename = textBox1.Text.Replace(":", "").Replace(";", ":").Trim();

            if (gamename == String.Empty)
            {
                MessageBox.Show(this, "Geben Sie einen Spielnamen an!", "Fehler.", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            ClearConnections();

            server = new TCPServer(port);
            server.ClientConnected += new NewClientConnection(ClientConnected);
            server.Start();

            broadcaster = new UdpBroadcaster(
                server.Port, 
                udpport,
                magicWord, 
                new KeyValuePair<string, string>[] 
                { 
                    new KeyValuePair<string, string>("Spielname", textBox1.Text.Replace(":","").Replace(";",":"))
                }
            );
            broadcaster.Start();

            maxconnections = (int)comboBox1.SelectedItem - 1;

            btnStart.Enabled = false;
            comboBox1.Enabled = false;
            textBox1.Enabled = false;
            btnAbort.Enabled = true;
        }

        internal void ClearConnections()
        {
            foreach (ClientInfo c in connections)
                c.Connection.Close();
            connections.Clear();
        }

        public TcpClient this[int index]
        {
            get
            {
                try
                {
                    return connections[index].Connection;
                }
                catch
                {
                    return null;
                }
            }
        }
    }
}