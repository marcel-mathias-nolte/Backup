using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Nolte.Net
{
    internal delegate void NewServerFound(object sender, NewServerFoundEventArgs e);

    internal class NewServerFoundEventArgs : EventArgs
    {
        public IPAddress IP;
        public int Port;
        public string Hostname;
        public string Username;
        public string Gamename;

        public NewServerFoundEventArgs(IPAddress IP, int Port, string Hostname, string Username, string Gamename)
        {
            this.IP = IP;
            this.Port = Port;
            this.Username = Username;
            this.Hostname = Hostname;
            this.Gamename = Gamename;
        }
    }

    internal class UdpListener
    {
        int udpport;
        string magicword;
        UdpClient listener;
        UdpState s;

        internal event NewServerFound ServerFound;

        internal void OnServerFound(IPAddress IP, int Port, string Hostname, string Username, string Gamename)
        {
            ServerFound(this, new NewServerFoundEventArgs(IP, Port, Hostname, Username, Gamename));
        }

        public UdpListener(int UDPPort, string MagicWord)
        {
            magicword = MagicWord;
            udpport = UDPPort;
            s = new UdpState();
            s.e = new IPEndPoint(IPAddress.Any, udpport);
            listener = new UdpClient(s.e);
            s.u = listener;
            listener.EnableBroadcast = true;
        }

        public void Start()
        {
            listener.BeginReceive(new AsyncCallback(Callback), s);
        }

        public void Stop()
        {
            listener.Close();
        }

        internal void Callback(IAsyncResult ar)
        {
            try
            {
                UdpClient u = (UdpClient)((UdpState)(ar.AsyncState)).u;
                IPEndPoint e = (IPEndPoint)((UdpState)(ar.AsyncState)).e;
                Byte[] receiveBytes = u.EndReceive(ar, ref e);
                string[] t, receiveString = Encoding.Unicode.GetString(receiveBytes).Split(';');
                if (receiveString[0] == magicword)
                {
                    Dictionary<string, string> args = new Dictionary<string, string>();
                    foreach (string s in receiveString)
                    {
                        t = s.Split(':');
                        if (t.Length > 1)
                            args.Add(t[0], t[1]);
                    }
                    if (args.ContainsKey("Message") && args["Message"] == "NOTIFY")
                    {
                        if (args.ContainsKey("Hostname") && args.ContainsKey("Username") && args.ContainsKey("Port") && args.ContainsKey("Spielname"))
                        {
                            OnServerFound(e.Address, Int32.Parse(args["Port"]), args["Hostname"], args["Username"], args["Spielname"]);
                        }
                    }
                }
            }
            catch { }
        }

        internal struct UdpState
        {
            public UdpClient u;
            public IPEndPoint e;
        }
    }
}
