using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Nolte.Net
{
    internal class UdpBroadcaster
    {
        Thread workerThread;
        volatile bool stopThread;
        string message;
        int udpport;

        public UdpBroadcaster(int TCPPort, int UDPPort, string MagicWord, KeyValuePair<string,string>[] Additional)
        {
            workerThread = new Thread(new ParameterizedThreadStart(Worker));
            stopThread = false;
            ThreadHandler.Add(workerThread);

            udpport = UDPPort;

            message = MagicWord +
                ";Message:NOTIFY" +
                ";Hostname:" + Dns.GetHostName() +
                ";Username:" + Environment.UserName +
                ";Port:" + TCPPort.ToString();
            foreach (KeyValuePair<string, string> add in Additional)
                message += ";" + add.Key + ":" + add.Value;
        }

        internal void Start()
        {
            workerThread.Start(message);
        }

        internal void Stop()
        {
            stopThread = true;
            Thread.Sleep(60);
            if (workerThread.ThreadState != ThreadState.Stopped)
                workerThread.Abort();
        }

        internal void Worker(object Message)
        {
            string message = (string)Message;
            UdpClient broadcaster;
            broadcaster = new UdpClient(new IPEndPoint(IPAddress.Any, 0));
            broadcaster.EnableBroadcast = true;
            int port = Thread.VolatileRead(ref udpport);

            byte[] data = Encoding.Unicode.GetBytes(message);

            int i = 10;
            
            while (!stopThread)
            {
                if (i == 10)
                {
                    broadcaster.Send(data, data.Length, new IPEndPoint(IPAddress.Broadcast, port));
                    i = 0;
                }
                i++;
                Thread.Sleep(30);
            }
            stopThread = false;
            broadcaster.Close();
        }
    }
}
