using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.IO;

namespace Nolte.Net
{
    public struct ServerInfo
    {
        public string Username, Hostname, Gamename;
        public IPAddress IP;
        public int Port;
    }

    public partial class GameClientDialog : Form
    {
        delegate void FinishHandler(TcpClient connection);
        FinishHandler Finishhandler;
        delegate void AddEntryHandler(string text);
        AddEntryHandler Addentryhandler;

        int port;
        UdpListener listener;
        string magicWord = Application.ProductName;
        Dictionary<string, ServerInfo> Servers;
        TcpClient connection;
        volatile bool AbortConnect;
        bool ThreadRunning;
        Thread worker;

        public GameClientDialog(string Title, ushort UDPPort)
        {
            InitializeComponent();
            Text = Title;
            port = UDPPort;
            Servers = new Dictionary<string, ServerInfo>();
            listener = new UdpListener(UDPPort, magicWord);
            listener.ServerFound += new NewServerFound(ServerFound);
            Finishhandler = new FinishHandler(Finish);
            Addentryhandler = new AddEntryHandler(AddEntry);
            listener.Start();
        }

        void AddEntry(string text)
        {
            listBox1.Items.Add(text);
        }

        void ServerFound(object sender, NewServerFoundEventArgs e)
        {
            ServerInfo si = new ServerInfo();
            si.Hostname = e.Hostname;
            si.IP = e.IP;
            si.Port = e.Port;
            si.Username = e.Username;
            si.Gamename = e.Gamename;

            string entry = e.Gamename + "[" + e.Username + "] @ " + e.Hostname;

            if (!Servers.ContainsKey(entry))
            {
                Servers.Add(entry, si);
                this.Invoke(Addentryhandler, new object[] { entry });
            }
        }

        /// <summary>
        /// Get/Set the unique identifier for data packages (at least 4 chars)
        /// </summary>
        public string MagicWord
        {
            get { return magicWord; }
            set { if (value.Length > 3) magicWord = value; }
        }

        private void btn_Abort_Click(object sender, EventArgs e)
        {
            if (ThreadRunning)
            {
                AbortConnect = true;
                worker.Abort();
                ThreadRunning = false;
            }
            else
            {
                listener.Stop();
                ThreadHandler.KillAll();
                Close();
            }
        }

        private void btn_Connect_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
            {
                ServerInfo server = Servers[(string)listBox1.SelectedItem];
                ParameterizedThreadStart pts = new ParameterizedThreadStart(Worker);
                worker = new Thread(pts);
                ThreadHandler.Add(worker);
                ThreadRunning = true;
                AbortConnect = false;
                btn_Connect.Enabled = false;
                worker.Start(server);
            }
        }

        public TcpClient Connection
        {
            get
            {
                return connection;
            }
        }

        public void Worker(object Serverinfo)
        {
            ServerInfo server = (ServerInfo)Serverinfo;
            StreamReader r;
            StreamWriter w;
            string[] s;
            TcpClient connection = new TcpClient();

            try
            {
                connection.Connect(server.IP, server.Port);
                r = new StreamReader(connection.GetStream());
                w = new StreamWriter(connection.GetStream());
                while (!AbortConnect)
                {
                    s = r.ReadLine().Split(' ');
                    switch (s[0])
                    {
                        case "EHLO":
                            w.WriteLine("EHLO");
                            w.Flush();
                            break;
                        case "GET":
                            if (s.Length > 1)
                            {
                                switch (s[1])
                                {
                                    case "USERNAME":
                                        w.WriteLine("USERNAME " + Environment.UserName);
                                        w.Flush();
                                        break;
                                }
                            }
                            break;
                        case "READY":
                            goto ENDE;
                    }
                }
                AbortConnect = false;
             ENDE:
                this.Invoke(Finishhandler, new object[] { connection });
                return;
            }
            catch
            {
                try
                {
                    connection.Close();
                }
                catch
                { }
                if (this.InvokeRequired)
                    this.Invoke(Finishhandler, new object[] { null });
                return;
            }
        }

        internal void Finish(TcpClient c)
        {
            if (c == null)
            {
                MessageBox.Show(this, "Fehler beim Verbinden zu Server", "Verbindungsfehler", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                btn_Connect.Enabled = true;
            }
            else
            {
                listener.Stop();
                this.DialogResult = DialogResult.OK;
                this.connection = c;
                ThreadHandler.KillAll();
                Close();
            }
        }

        private void GameClientDialog_FormClosing(object sender, FormClosingEventArgs e)
        {
            listener.Stop();
            this.DialogResult = DialogResult.Cancel;
            ThreadHandler.KillAll();
        }

    }
}