using System;
using System.Collections.Generic;
using System.Threading;

namespace Nolte.Net
{
    internal static class ThreadHandler
    {
        internal static List<Thread> Threads = new List<Thread>();

        public static void Add(Thread t)
        {
            Threads.Add(t);
        }

        public static void KillAll()
        {
            foreach (Thread t in Threads)
                try
                {
                    t.Abort();
                }
                catch 
                { }
        }
    }
}
