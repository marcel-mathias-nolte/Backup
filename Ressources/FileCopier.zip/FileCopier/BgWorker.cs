using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace FileCopier
{
    public partial class BgWorker : Form
    {
        public BgWorker()
        {
            InitializeComponent();
        }

        private List<Form> windows;
        private int current;

        private void BgWorker_Load(object sender, EventArgs e)
        {
            this.windows = new List<Form>();
            this.windows.Add(new Schritt1Quelle());

            this.current = 0;
            this.Work();
        }
        private void Work()
        {
            DialogResult dr;
            Form f;
            Point l = new Point();
            do
            {
                f = this.windows[this.current];
                if (l.IsEmpty)
                    f.Location = l;
                f.Show();
                dr = ((DialogForm)f).Wait();
                if (dr == DialogResult.OK)
                    this.current++;
                else if (dr == DialogResult.Cancel)
                    this.current--;
            }
            while (dr != DialogResult.Abort);
            Application.Exit();
        }
        public Form this[int index]
        {
            get
            {
                return this.windows[index];
            }
        }
    }
}