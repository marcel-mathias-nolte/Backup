using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace FileCopier
{
    public class DialogForm : Form
    {
        public DialogResult Wait()
        {
            while (this.DialogResult == DialogResult.None)
                Application.DoEvents();
            return this.DialogResult;
        }
    }
}
