﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace FileCopier
{
    static class Program
    {
        public static Form Core;
        /// <summary>
        /// Der Haupteinstiegspunkt für die Anwendung.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Program.Core = new BgWorker();
            Application.Run(Program.Core);
        }
    }
}