using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace FileCopier
{
    public partial class Schritt1Quelle : DialogForm
    {
        public Schritt1Quelle()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Abort;
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!System.IO.Directory.Exists(this.textBox1.Text))
            {
                MessageBox.Show("Sie haben ein ung�ltiges Verzeichnis angegeben!", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            this.DialogResult = DialogResult.OK;
            this.Hide();
        }


        public System.IO.DirectoryInfo Directory
        {
            get
            {
                return new System.IO.DirectoryInfo(this.textBox1.Text);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            System.IO.DirectoryInfo di;
            if (Properties.Settings.Default.source.Length > 0)
                di = new System.IO.DirectoryInfo(Properties.Settings.Default.source);
            else
                di = new System.IO.DirectoryInfo(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments));
            while (!di.Exists && di.FullName != di.Root.FullName)
                di = di.Parent;
            if (!di.Exists)
                di = new System.IO.DirectoryInfo(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments));

            fbd.SelectedPath = di.FullName;
            DialogResult dr = fbd.ShowDialog();
            if (dr == DialogResult.OK)
                textBox1.Text = fbd.SelectedPath;
            Properties.Settings.Default.source = fbd.SelectedPath;
            fbd.Dispose();
        }
    }
}