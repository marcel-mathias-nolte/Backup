using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;
using System.ComponentModel;

namespace Tagreader
{
    // written by Marcel Nolte
    public class ID3Tags
    {
        public string Title, Artist, Album, Band, Year, Track, Genre;
        public ID3Tags(string filename)
        {
            WMAID3Tag w;
            ID3V1Tag i;
            string ext = filename.Substring(filename.LastIndexOf('.') + 1);
            switch (ext.ToLower())
            {
                case "wma":
                    try
                    {
                        w = new WMAID3Tag(filename);
                    }
                    catch
                    {
                        return;
                    }
                    Title = w.title;
                    Artist = w.artist;
                    Album = w.album;
                    Band = w.band;
                    Year = w.year.ToString();
                    Track = w.track.ToString();
                    Genre = w.genre;
                    break;
                case "mp3":
                    ID3TagLib.ID3File file = new ID3TagLib.ID3File(filename);
                    ID3TagLib.ID3v2Tag v2Tag = file.ID3v2Tag;
                    if (v2Tag != null)
                    {
                        ID3TagLib.TextFrame f;
                        f = (ID3TagLib.TextFrame)v2Tag.Frames[ID3TagLib.FrameFactory.BandFrameId];
                        Band = f.Text;
                        f = (ID3TagLib.TextFrame)v2Tag.Frames[ID3TagLib.FrameFactory.AlbumFrameId];
                        Album = f.Text;
                        f = (ID3TagLib.TextFrame)v2Tag.Frames[ID3TagLib.FrameFactory.TitleFrameId];
                        Title = f.Text;
                        f = (ID3TagLib.TextFrame)v2Tag.Frames[ID3TagLib.FrameFactory.LeadArtistFrameId];
                        Artist = f.Text;
                        f = (ID3TagLib.TextFrame)v2Tag.Frames[ID3TagLib.FrameFactory.ContentTypeFrameId];
                        Genre = f.Text;
                        f = (ID3TagLib.TextFrame)v2Tag.Frames[ID3TagLib.FrameFactory.YearFrameId];
                        Year = f.Text;
                        f = (ID3TagLib.TextFrame)v2Tag.Frames[ID3TagLib.FrameFactory.TrackNumberFrameId];
                        Track = f.Text;
                        break;
                    }
                    try
                    {
                        i = new ID3V1Tag(filename);
                    }
                    catch
                    {
                        return;
                    }
                    Title = i.title;
                    Artist = i.artist;
                    Album = i.album;
                    Band = "";
                    Year = i.year.ToString();
                    Track = i.track.ToString();
                    Genre = i.genre;
                    break;
                case "ogg":
                    OggReader o = new OggReader(filename);
                    Band = o.Band;
                    Artist = o.Artist;
                    Album = o.Album;
                    Track = o.TrackNumber;
                    Title = o.Title;
                    Genre = o.Genre;
                    Year = o.Date;
                    break;
                default:
                    break;
            }
        }
    }
    public class ID3V1Tag
    {
        public string title, artist, album, genre, comment;
        public int year, track;
        public FileStream stream;
        private BinaryReader br;
        #region Genre Strings
        private string[] genres = 
        {
            "Blues", "Classic Rock", "Country", "Dance", "Disco", "Funk", "Grunge", "Hip-Hop",
            "Jazz", "Metal", "New Age", "Oldies", "Other", "Pop", "R&B", "Rap",
            "Reggae", "Rock", "Techno", "Industrial", "Alternative", "Ska", "Death Metal",
            "Pranks", "Soundtrack", "Euro-Techno", "Ambient", "Trip-Hop", "Vocal", "Jazz+Funk",
            "Fusion", "Trance", "Classical", "Instrumental", "Acid", "House", "Game",
            "Sound Clip", "Gospel", "Noise", "Alt. Rock", "Bass", "Soul", "Punk", "Space",
            "Meditative", "Instrumental Pop", "Instrumental Rock", "Ethnic", "Gothic", 
            "Darkwave", "Techno-Industrial", "Electronic", "Pop-Folk", "Eurodance", "Dream", 
            "Southern Rock", "Comedy", "Cult", "Gangsta Rap", "Top 40", "Christian Rap",
            "Pop/Funk", "Jungle", "Native American", "Cabaret", "New Wave", "Psychedelic", 
            "Rave", "Showtunes", "Trailer", "Lo-Fi", "Tribal", "Acid Punk", "Acid Jazz", "Polka", 
            "Retro", "Musical", "Rock & Roll", "Hard Rock", "Folk", "Folk/Rock",
            "National Folk", "Swing", "Fast-Fusion", "Bebop", "Latin", "Revival", "Celtic",
            "Bluegrass", "Avantgarde", "Gothic Rock", "Progressive Rock", "Psychedelic Rock",
            "Symphonic Rock", "Slow Rock", "Big Band", "Chorus", "Easy Listening", "Acoustic", 
            "Humour", "Speech", "Chanson", "Opera", "Chamber Music", "Sonata", "Symphony",
            "Booty Bass", "Primus", "Porn Groove", "Satire", "Slow Jam", "Club", "Tango",
            "Samba", "Folklore", "Ballad", "Power Ballad", "Rhythmic Soul", "Freestyle", "Duet",
            "Punk Rock", "Drum Solo", "A Cappella", "Euro-House", "Dance Hall", "Goa", 
            "Drum & Bass", "Club-House", "Hardcore", "Terror", "Indie", "BritPop", "Negerpunk",
            "Polsk Punk", "Beat", "Christian Gangsta Rap", "Heavy Metal", "Black Metal",
            "Crossover", "Contemporary Christian", "Christian Rock", "Merengue", "Salsa",
            "Thrash Metal"
        };
        #endregion
        public ID3V1Tag(string fn)
        {
            byte b;
            string s;
            double d;

            try
            {
                stream = new FileStream(fn, FileMode.Open);
                br = new BinaryReader(stream);
            }
            catch
            {
                throw new Exception("Could not open " + fn);
            }

            try
            {
                stream.Seek(-128, SeekOrigin.End);
                s = new String(br.ReadChars(3));
                if (s != "TAG")
                {
                    throw new Exception("No Valid ID3V1.1 tag information");
                }
                title = new String(br.ReadChars(30));
                artist = new String(br.ReadChars(30));
                album = new String(br.ReadChars(30));
                s = new String(br.ReadChars(4));
                if (Double.TryParse(s, out d))
                    year = Convert.ToInt32(s);
                else
                    year = 0;
                comment = new String(br.ReadChars(28));
                b = br.ReadByte();
                b = br.ReadByte();
                track = Convert.ToInt32(b);
                b = br.ReadByte();
                genre = genres[Convert.ToInt32(b)];
            }
            catch
            {
                throw new Exception("ID3 V1.1 tag information not valid in " + fn);
            }
            finally
            {
                br.Close();
                stream.Close();
            }
        }
    }
    public class WMAID3Tag
    {
        /*
         *  This class will read all the attributes from the ContextBlock and ExtendedContextBlock in a WMA file
         *  It makes available the attributes that are most interesting directly, and allows the retrieval on any string attribute by name.
         *  Could easily be extended to allow the retrieval of non-string attributes, I just didn't need them.
         *  I couldn't find an easy way to have a resumable enumeration over a hash table (there's not items() array) I didn't 
         *  implement an enumerator.  It wouldn't be hard to do, just clumsy.
         */
        public string title, artist, album, genre, copyright, description, rating, band;
        public int year, track;
        private FileStream stream;
        private BinaryReader br;
        private Hashtable attrs = new Hashtable();
        private ArrayList attrValues = new ArrayList();
        private struct value
        {
            public Int16 dataType;
            public int index;
        }
        // WMA GUIDs
        private Guid hdrGUID = new Guid("75B22630-668E-11CF-A6D9-00AA0062CE6C");
        private Guid contentGUID = new Guid("75B22633-668E-11CF-A6D9-00AA0062CE6C");
        private Guid extendedContentGUID = new Guid("D2D0A440-E307-11D2-97F0-00A0C95EA850");
        public WMAID3Tag(string fn)
        {
            Guid g;
            bool CBDone = false, ECBDone = false;
            long sizeBlock;
            string s;
            int i;
            double d;

            try
            {
                stream = new FileStream(fn, FileMode.Open, FileAccess.Read);
                br = new BinaryReader(stream);
            }
            catch
            {
                // Could not open fn
                return;
            }

            readGUID(out g);

            if (!Guid.Equals(g, hdrGUID))
            {
                throw new Exception("Invalid WMA file format.");
            }
            br.ReadInt64();  // the size of the entire block
            br.ReadInt32();  // the number of entries
            br.ReadBytes(2); // two reserved bytes
            // Process all the GUIDs until you get both the contextblock and the extendedcontextblock
            while (readGUID(out g))
            {
                sizeBlock = br.ReadInt64(); // this is the size of the block
                // shouldn't happen, but at least fail gracefully
                if (br.BaseStream.Position + sizeBlock > stream.Length) break;
                if (Guid.Equals(g, contentGUID))
                {
                    processContentBlock();
                    if (ECBDone) break;
                    CBDone = true;
                }
                else if (Guid.Equals(g, extendedContentGUID))
                {
                    processExtendedContentBlock();
                    if (CBDone) break;
                    ECBDone = true;
                }
                else
                {
                    // not one we're interested in, skip it
                    sizeBlock -= 24; // already read the guid header info
                    br.BaseStream.Position += sizeBlock;
                }
            }
            // Get the attributes we're interested in
            album = getStringAttribute("WM/AlbumTitle");
            genre = getStringAttribute("WM/Genre");
            band = getStringAttribute("WM/AlbumArtist");
            s = getStringAttribute("WM/Year");
            if (Double.TryParse(s, out d))
                year = Convert.ToInt32(s);
            else
                year = 0;
            s = getStringAttribute("WM/TrackNumber");
            // could be n/<total>
            i = s.IndexOf("/");
            if (i != -1) s = s.Substring(0, i);
            if (Double.TryParse(s, out d))
            {
                track = Convert.ToInt32(s);
            }
            else
            {
                s = getStringAttribute("WM/Track");
                i = s.IndexOf("/");
                if (i != -1) s = s.Substring(0, i);
                if (Double.TryParse(s, out d))
                    track = Convert.ToInt32(s);
                else
                    track = 0;
            }
        }
        private string readUnicodeString(Int16 len)
        {
            // Can't use .NET functions, since they expect the length field to be a single byte for strings < 256 chars
            char[] ch;
            int i;
            short k;

            ch = new char[len - 1];
            for (i = 0; i <= len - 2; i++)
            {
                k = br.ReadInt16();
                ch[i] = (char)k;
            }
            k = br.ReadInt16();
            return new String(ch);
        }
        private string readUnicodeString()
        {
            Int16 datalen, len;
            // Can't use .NET functions, since they expect the length field to be a single byte for strings < 256 chars
            datalen = br.ReadInt16();
            len = Convert.ToInt16(datalen / 2); // length in Unicode characters
            return readUnicodeString(len);
        }
        private void processExtendedContentBlock()
        {
            Int16 numAttrs, dataType, dataLen, sValue;
            string attrName, strValue;
            byte[] bValue;
            bool boolValue;
            int iValue, index = 0;
            long lValue;
            value valueObject;

            numAttrs = br.ReadInt16();
            for (int j = 0; j < numAttrs; j++)
            {
                attrName = readUnicodeString();
                dataType = br.ReadInt16();
                switch (dataType)
                {
                    case 0:
                        strValue = readUnicodeString();
                        valueObject.dataType = 0;
                        valueObject.index = index;
                        attrs.Add(attrName, valueObject);
                        attrValues.Add(strValue);
                        index++;
                        break;
                    case 1:
                        dataLen = br.ReadInt16();
                        bValue = br.ReadBytes(dataLen);
                        valueObject.dataType = 1;
                        valueObject.index = index;
                        attrs.Add(attrName, valueObject);
                        attrValues.Add(bValue);
                        index++;
                        break;
                    case 2:
                        dataLen = br.ReadInt16();
                        iValue = br.ReadInt32();
                        if (iValue == 0)
                            boolValue = false;
                        else
                            boolValue = true;
                        valueObject.dataType = 2;
                        valueObject.index = index;
                        attrs.Add(attrName, valueObject);
                        attrValues.Add(boolValue);
                        index++;
                        break;
                    case 3:
                        dataLen = br.ReadInt16();
                        iValue = br.ReadInt32();
                        valueObject.dataType = 3;
                        valueObject.index = index;
                        attrs.Add(attrName, valueObject);
                        attrValues.Add(iValue);
                        index++;
                        break;
                    case 4:
                        dataLen = br.ReadInt16();
                        lValue = br.ReadInt64();
                        valueObject.dataType = 4;
                        valueObject.index = index;
                        attrs.Add(attrName, valueObject);
                        attrValues.Add(lValue);
                        index++;
                        break;
                    case 5:
                        dataLen = br.ReadInt16();
                        sValue = br.ReadInt16();
                        valueObject.dataType = 5;
                        valueObject.index = index;
                        attrs.Add(attrName, valueObject);
                        attrValues.Add(sValue);
                        index++;
                        break;
                    default:
                        throw new Exception("Bad value for datatype in Extended Content Block. Value = " + dataType.ToString());
                }
            }
        }
        private void processContentBlock()
        {
            short lTitle, lAuthor, lCopyright, lDescription, lRating;

            lTitle = br.ReadInt16();
            lAuthor = br.ReadInt16();
            lCopyright = br.ReadInt16();
            lDescription = br.ReadInt16();
            lRating = br.ReadInt16();
            if (lTitle > 0)
                title = readUnicodeString(Convert.ToInt16(lTitle / 2));
            if (lAuthor > 0)
                artist = readUnicodeString(Convert.ToInt16(lAuthor / 2));
            if (lCopyright > 0)
                copyright = readUnicodeString(Convert.ToInt16(lCopyright / 2));
            if (lDescription > 0)
                description = readUnicodeString(Convert.ToInt16(lDescription / 2));
            if (lRating > 0)
                rating = readUnicodeString(Convert.ToInt16(lRating / 2));
        }
        private bool readGUID(out Guid g)
        {
            int int1;
            short shrt1, shrt2;
            byte[] b;

            try
            {
                int1 = br.ReadInt32();
                if (int1 == -1)
                {
                    g = new Guid();
                    return false;
                }
                shrt1 = br.ReadInt16();
                shrt2 = br.ReadInt16();
                b = br.ReadBytes(8);
                g = new Guid(int1, shrt1, shrt2, b);
                return true;
            }
            catch
            {
                throw new Exception("Invalid WMA format.");
            }
        }
        public string getStringAttribute(string name)
        {
            value v;

            if (!attrs.Contains(name)) return "";
            v = (value)attrs[name];
            if (v.dataType != 0)
                return ""; // it's not a string type
            else
                return (string)attrValues[v.index];
        }
    }
}
