using System;
using System.IO;
using MediaInfoLib;
using System.Drawing;
using System.Windows.Forms;
using Tagreader;

namespace MediaIndexer
{
    public static class Media
    {
        /// <summary>
        /// Liest die Informationen der angegebenen Datei
        /// </summary>
        /// <param name="file">Die zu indizierende Datei</param>
        public static Info Index(FileInfo file)
        {
            MediaInfo mi = new MediaInfo();
            Info info = null;
            mi.Open(file.FullName);
            mi.Option("Complete", "1");

            if (mi.Count_Get(StreamKind.Video) > 0) info = new Videoinfo(mi, file);
            else if (mi.Count_Get(StreamKind.Audio) > 0) info = new Audioinfo(mi, file);
            else if (mi.Count_Get(StreamKind.Image) > 0) info = new Imageinfo(mi, file);

            //            Program.Handle.y(((Videoinfo)info).Preview);

            mi.Close();
            return info;
        }
    }
    /// <summary>
    /// Common file information
    /// </summary>
    public class Info
    {
        public uint Filesize = 0;
        public string Folder = "", Filename = "";
        /// <summary>
        /// Infotypen
        /// </summary>
        public enum Kinds : uint
        {
            Video,
            Audio,
            Image,
            Unknown
        }
        public Kinds Kind = Kinds.Unknown;
    }
    /// <summary>
    /// Video file information
    /// </summary>
    public class Videoinfo : Info
    {
        public uint Duration = 0;
        public VideoChannel Video = null;
        public AudioChannel Audio1 = null;
        public AudioChannel Audio2 = null;
        public Image Cover = null, Preview = null;
        public string CoverFilename = "", PreviewFilename = "";
        public uint CoverFilesize = 0, PreviewFilesize = 0;
        public string Title = "";

        /// <summary>
        /// Creates a new video information collection
        /// </summary>
        /// <param name="info">An instance of MediaInfo</param>
        public Videoinfo(MediaInfo info, FileInfo file)
        {
            Video = new VideoChannel();
            Audio1 = new AudioChannel();
            if (info.Count_Get(StreamKind.Audio) > 1)
                Audio2 = new AudioChannel();
            else
                Audio2 = null;

            // General
            if (!UInt32.TryParse(info.Get(StreamKind.General, 0, "Duration"), out Duration)) Duration = 0;
            if (!UInt32.TryParse(info.Get(StreamKind.General, 0, "FileSize"), out Filesize)) Filesize = 0;
            Folder = file.DirectoryName;
            Filename = file.Name;
            Title = Filename2Title(Filename.Substring(0, Filename.LastIndexOf('.')));

            // Video
            Video.Codec = info.Get(StreamKind.Video, 0, "Codec/String");
            Video.CodecFamily = info.Get(StreamKind.Video, 0, "Format");
            if (!UInt32.TryParse(info.Get(StreamKind.Video, 0, "BitRate"), out Video.Bitrate)) Video.Bitrate = 0;
            if (!UInt32.TryParse(info.Get(StreamKind.Video, 0, "Height"), out Video.Height)) Video.Height = 0;
            if (!UInt32.TryParse(info.Get(StreamKind.Video, 0, "Width"), out Video.Width)) Video.Width = 0;
            Video.AspectRatio = info.Get(StreamKind.Video, 0, "DisplayAspectRatio/String");
            if (!Double.TryParse(info.Get(StreamKind.Video, 0, "FrameRate"), out Video.Framerate)) Video.Framerate = 0;
            Video.Framerate = Math.Round(Video.Framerate / 1000, 3);
            Video.Chroma = info.Get(StreamKind.Video, 0, "Colorimetry");
            Video.Interlacement = info.Get(StreamKind.Video, 0, "Interlacement/String");

            // Audio1
            Audio1.Codec = info.Get(StreamKind.Audio, 0, "Codec/String");
            if (!UInt32.TryParse(info.Get(StreamKind.Audio, 0, "BitRate"), out Audio1.Bitrate)) Audio1.Bitrate = 0;
            if (!UInt32.TryParse(info.Get(StreamKind.Audio, 0, "Channel(s)"), out Audio1.Channels)) Audio1.Channels = 0;
            if (!UInt32.TryParse(info.Get(StreamKind.Audio, 0, "Resolution"), out Audio1.Resolution)) Audio1.Resolution = 0;
            if (!UInt32.TryParse(info.Get(StreamKind.Audio, 0, "SamplingRate"), out Audio1.SamplingRate)) Audio1.SamplingRate = 0;

            // Audio2
            if (info.Count_Get(StreamKind.Audio) > 1)
            {
                Audio2.Codec = info.Get(StreamKind.Audio, 1, "Codec/String");
                if (!UInt32.TryParse(info.Get(StreamKind.Audio, 0, "BitRate"), out Audio2.Bitrate)) Audio2.Bitrate = 0;
                if (!UInt32.TryParse(info.Get(StreamKind.Audio, 0, "Channel(s)"), out Audio2.Channels)) Audio2.Channels = 0;
                if (!UInt32.TryParse(info.Get(StreamKind.Audio, 0, "Resolution"), out Audio2.Resolution)) Audio2.Resolution = 0;
                if (!UInt32.TryParse(info.Get(StreamKind.Audio, 0, "SamplingRate"), out Audio2.SamplingRate)) Audio2.SamplingRate = 0;
            }

            // try to find suitable images
            string stub = file.FullName.Substring(0, file.FullName.Length - file.Extension.Length + 1);
            string[] validext = { "jpg", "jpeg", "bmp", "tif", "tiff", "png" };
            foreach (string ext in validext)
            {
                if (File.Exists(stub + ext))
                {
                    PreviewFilename = stub + ext;
                    Preview = Image.FromFile(PreviewFilename);
                    PreviewFilesize = (uint)(new FileInfo(PreviewFilename)).Length;
                    break;
                }
            }
            foreach (string ext in validext)
            {
                if (File.Exists(stub + "cover." + ext))
                {
                    CoverFilename = stub + "cover." + ext;
                    Cover = Image.FromFile(CoverFilename);
                    CoverFilesize = (uint)(new FileInfo(CoverFilename)).Length;
                    break;
                }
            }

            Kind = Kinds.Video;
        }
        /// <summary>
        /// Converts Filenames to Titles
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        public static string Filename2Title(string filename)
        {
            string[] Silben =
                {
                    "der",
                    "die",
                    "das",
                    "eine",
                    "ein",
                    "a",
                    "the"
                };
            string fn = filename.ToLower();
            foreach (string Silbe in Silben)
            {
                if (fn.StartsWith(Silbe + " "))
                {
                    filename = filename.Substring(Silbe.Length).Trim() + ", " + Silbe.Substring(0, 1).ToUpper() + Silbe.Substring(1);
                }
            }
            return filename;
        }
    }
    /// <summary>
    /// Audio file information
    /// </summary>
    public class Audioinfo : Info
    {
        public uint Duration = 0;
        public Image Cover = null;
        public string CoverFilename = null;
        public uint CoverFilesize = 0;
        public AudioChannel Audio = null;
        public struct SAInfo
        {
            public string Artist;
            public string Title;
            public SAInfo(string A, string T)
            {
                Artist = A;
                Title = T;
            }
        }
        public SAInfo Album = new SAInfo("","");
        public SAInfo Song = new SAInfo("","");
        public int Year = 0;
        public string Genre;
        public int Track = 0;

        /// <summary>
        /// Creates a new audio information collection
        /// </summary>
        /// <param name="info">An instance of MediaInfo</param>
        public Audioinfo(MediaInfo info, FileInfo file)
        {
            Audio = new AudioChannel();

            // General
            if (!UInt32.TryParse(info.Get(StreamKind.General, 0, "Duration"), out Duration)) Duration = 0;
            if (!UInt32.TryParse(info.Get(StreamKind.General, 0, "FileSize"), out Filesize)) Filesize = 0;
            Folder = file.DirectoryName;
            Filename = file.Name;

            // Audio
            Audio.Codec = info.Get(StreamKind.Audio, 0, "Codec/String");
            if (!UInt32.TryParse(info.Get(StreamKind.Audio, 0, "BitRate"), out Audio.Bitrate)) Audio.Bitrate = 0;
            if (!UInt32.TryParse(info.Get(StreamKind.Audio, 0, "Channel(s)"), out Audio.Channels)) Audio.Channels = 0;
            if (!UInt32.TryParse(info.Get(StreamKind.Audio, 0, "Resolution"), out Audio.Resolution)) Audio.Resolution = 0;
            if (!UInt32.TryParse(info.Get(StreamKind.Audio, 0, "SamplingRate"), out Audio.SamplingRate)) Audio.SamplingRate = 0;

            string[] validext = { "cover.jpg", "cover.jpeg", "folder.jpg", "folder.jpeg", "front.jpg", "front.jpeg" };
            foreach (string ext in validext)
            {
                if (File.Exists(file.DirectoryName + Path.DirectorySeparatorChar.ToString() + ext))
                {
                    try
                    {
                        Cover = Image.FromFile(file.DirectoryName + Path.DirectorySeparatorChar.ToString() + ext);
                        CoverFilename = file.DirectoryName + Path.DirectorySeparatorChar.ToString() + ext;
                        CoverFilesize = (uint)(new FileInfo(CoverFilename)).Length;
                        break;
                    }
                    catch { }
                }
            }

            ID3Tags T = new ID3Tags(Filename);
            #region Album
            if (!T.Band.Trim().Equals(""))
            {
                Album.Artist = T.Band.Trim();
            }
            else
            {
                if (!T.Artist.Trim().Equals(""))
                {
                    Album.Artist = T.Artist.Trim();
                }
            }
            if (!T.Album.Trim().Equals(""))
            {
                Album.Title = T.Album.Trim();
            }
            #endregion
            #region Song
            string[] fn = Filename.Substring(0, Filename.LastIndexOf('.')).Split('-');
            if (!T.Artist.Trim().Equals(""))
            {
                Song.Artist = T.Artist.Trim();
            }
            else
            {
                if (!T.Band.Trim().Equals(""))
                {
                    Song.Artist = T.Band.Trim();
                }
                else
                {
                    Song.Artist = fn[0];
                    // Song.Artist = "Unknown Artist";
                }
            }
            if (!T.Title.Trim().Equals(""))
            {
                Song.Title = T.Title.Trim();
            }
            else
            {
                Song.Title = fn[fn.Length - 1];
            }
            Int32.TryParse(T.Track, out Track);
            Genre = T.Genre;
            Int32.TryParse(T.Year, out Year);
            #endregion
            Kind = Kinds.Audio;
        }
    }
    /// <summary>
    /// Audio file information
    /// </summary>
    public class Imageinfo : Info
    {
        public string Codec = "", CodecFamily = "";
        public uint Height = 0, Width = 0, Resolution = 0;
        public Image Thumbnail = null;
        /// <summary>
        /// Creates a new audio information collection
        /// </summary>
        /// <param name="info">An instance of MediaInfo</param>
        public Imageinfo(MediaInfo info, FileInfo file)
        {

            // General
            if (!UInt32.TryParse(info.Get(StreamKind.Image, 0, "Width"), out Width)) Width = 0;
            if (!UInt32.TryParse(info.Get(StreamKind.Image, 0, "Height"), out Height)) Height = 0;
            if (!UInt32.TryParse(info.Get(StreamKind.Image, 0, "Resolution"), out Resolution)) Resolution = 0;
            Codec = info.Get(StreamKind.Image, 0, "Codec");
            CodecFamily = info.Get(StreamKind.General, 0, "Codec/Info");
            Folder = file.DirectoryName;
            Filename = file.Name;

            Image img;
            try
            {
                img = Image.FromFile(file.FullName);
                if (Width > Height)
                    Thumbnail = img.GetThumbnailImage(100, (int)(100 * Height / Width), new Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                else if (Height > Width)
                    Thumbnail = img.GetThumbnailImage((int)(100 * Width / Height), 100, new Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
                else
                    Thumbnail = img.GetThumbnailImage(100, 100, new Image.GetThumbnailImageAbort(ThumbnailCallback), IntPtr.Zero);
            }
            catch
            {
                img = (Bitmap)(new Bitmap(100, 100));
                Graphics g = Graphics.FromImage(img);
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighSpeed;
                g.FillRectangle(Brushes.Black, 0, 0, 99, 99);
                Pen p = (Pen)Pens.Red.Clone();
                g.DrawLines(Pens.Red, new Point[] { new Point(0, 0), new Point(0, 99), new Point(99, 0), new Point(0, 0), new Point(99, 99), new Point(0, 99) });
                Thumbnail = img;
            }
            Kind = Kinds.Image;
        }
        public bool ThumbnailCallback()
        {
            return true;
        }
    }
    /// <summary>
    /// Video stream information
    /// </summary>
    public class VideoChannel
    {
        public string Codec = "", CodecFamily = "", AspectRatio = "", Chroma = "", Interlacement = "";
        public uint Bitrate = 0, Width = 0, Height = 0;
        public double Framerate;
    }
    /// <summary>
    /// Audio stream information
    /// </summary>
    public class AudioChannel
    {
        public string Codec = "";
        public uint Bitrate = 0, Channels = 0, Resolution = 0, SamplingRate = 0;
    }
}
